[Skip to main content](https://webflow.com/updates/truncate-content-text-overflow#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

Sign up - Webflow

[Go to Webflow](https://webflow.com/)

Welcome to Webflow!

Continue

* * *

or

* * *

Sign up with GoogleSign up with Google

Sign In - Google Accounts

Sign up with GoogleSign up with Google

Signing up for a Webflow account means you agree to the [Privacy Policy](http://www.webflow.com/legal/privacy) and [Terms of Service](http://www.webflow.com/legal/terms)

Have an account? [Sign in](https://webflow.com/login)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

[update](http://www.webflow.com/updates)

Enhancement

Layout & design

# Truncate long content with text overflow

Use the text overflow CSS property to truncate content that’s too long with an ellipsis. Our smart guidance ensures proper setup, making text truncation seamless.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e45431ca330e2f6eaf4f21_SlashUpdates_1280x720.webp)

[updates](http://www.webflow.com/updates)

→

Truncate long content with text overflow

Enhancement

Layout & design

# Truncate long content with text overflow

Use the text overflow CSS property to truncate content that’s too long with an ellipsis. Our smart guidance ensures proper setup, making text truncation seamless.

In this update

[Documentation\\
\\
→](https://help.webflow.com/hc/en-us/articles/33961409134227-Control-text-wrapping-line-breaking-and-truncation#h_01JQ507TFR1HW7FK38S3T1YMKR)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/truncate-content-text-overflow&text=Truncate%20long%20content%20with%20text%20overflow)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/truncate-content-text-overflow)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/truncate-content-text-overflow&title=Truncate%20long%20content%20with%20text%20overflow&summary=Use%20the%20text%20overflow%20CSS%20property%20to%20truncate%20content%20that%E2%80%99s%20too%20long%20with%20an%20ellipsis.%20Our%20smart%20guidance%20ensures%20proper%20setup,%20making%20text%20truncation%20seamless.)

![The Webflow Style panel indicating a new "Truncate" property with two options: clip and ellipsis](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e45431ca330e2f6eaf4f21_SlashUpdates_1280x720.webp)

We’ve added a new capability in the Style panel that lets you easily apply an ellipsis when your text content would otherwise overflow —rather than manually hunting through style settings or memorizing CSS requirements.

You’ll find this option in the Styles panel under **Typography → More type options → Truncate**, where you can enable an ellipsis to indicate when text is clipped.

Because `text-overflow` only works when paired with specific supporting styles ( `overflow: hidden` and `white-space: nowrap`), we’ve built in smart guidance. When you enable truncation, we’ll let you know if any additional properties need to be applied —and give you a single-click way to apply them, right from the Typography section.

For more detailed instructions on how to start leveraging this feature, [visit our Help Center](https://help.webflow.com/hc/en-us/articles/33961409134227-Control-text-wrapping-line-breaking-and-truncation#h_01JQ507TFR1HW7FK38S3T1YMKR).

Launched on

March 26, 2025

Category

Layout & design

[Documentation\\
\\
→](https://help.webflow.com/hc/en-us/articles/33961409134227-Control-text-wrapping-line-breaking-and-truncation#h_01JQ507TFR1HW7FK38S3T1YMKR)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/truncate-content-text-overflow&text=Truncate%20long%20content%20with%20text%20overflow)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/truncate-content-text-overflow)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/truncate-content-text-overflow&title=Truncate%20long%20content%20with%20text%20overflow&summary=Use%20the%20text%20overflow%20CSS%20property%20to%20truncate%20content%20that%E2%80%99s%20too%20long%20with%20an%20ellipsis.%20Our%20smart%20guidance%20ensures%20proper%20setup,%20making%20text%20truncation%20seamless.)

## Related updates

[Slide left\\
\\
←](https://webflow.com/updates/truncate-content-text-overflow#) [Slide right\\
\\
→](https://webflow.com/updates/truncate-content-text-overflow#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/674600afc3032da6efd11645_text-decor-update-alt.jpg)

Enhancement

Layout & design

## Text Decoration Styles

Learn more

→

[View Text Decoration Styles](https://webflow.com/updates/text-decoration-styles)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/673be3c8eeb916a51a95e220_number-percentage-vars-update.jpg)

Enhancement

Layout & design

## New variable types: Number and Percentage

Learn more

→

[View New variable types: Number and Percentage](https://webflow.com/updates/new-variable-types-number-percentage)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/673cc7ee566da9bd9b59da04_thumbnail_1280x720_component-style-variants.jpg)

Feature

Layout & design

## Component style variants is now available

Learn more

→

[View Component style variants is now available](https://webflow.com/updates/component-style-variants-now-available)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66e08f9bf144a72ae8d84324_scaled-vars-update.png)

Feature

Layout & design

## Manage variables at scale with reordering and bulk actions

Learn more

→

[View Manage variables at scale with reordering and bulk actions](https://webflow.com/updates/variable-reordering-bulk-actions)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66bd0e0ede1635add4777d3e_SlashUpdates_1280x720%E2%80%93drop-shadow.jpg)

Enhancement

Layout & design

## Drop shadow filters

Learn more

→

[View Drop shadow filters](https://webflow.com/updates/drop-shadows)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/666309cfef1d1527bfaabba7_Important-SlashUpdates_1280x720.jpg)

Enhancement

Layout & design

## !important flag in Webflow custom properties

Learn more

→

[View !important flag in Webflow custom properties](https://webflow.com/updates/important-custom-properties)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66353cf4cfd4f56cb433ebed_style-panel-updates.webp)

Feature

Layout & design

## Additional sizing and layout controls

Learn more

→

[View Additional sizing and layout controls](https://webflow.com/updates/additional-sizing-and-layout-controls)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a26cdf68fe32b132f378_SlashUpdates_1280x720_pin-ruler.jpg)

Feature

Layout & design

## Pinned ruler and crosshair

Learn more

→

[View Pinned ruler and crosshair](https://webflow.com/updates/pinned-ruler-and-crosshair)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65bbf5889d200acf90bb019f_SlashUpdates_1280x720.jpg)

Enhancement

Layout & design

## Group your component properties

Learn more

→

[View Group your component properties](https://webflow.com/updates/group-your-component-properties)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65aaa8d6b9d852461eee82d2_SlashUpdates_1280x720.webp)

Enhancement

Layout & design

## X & Y offsets for shadows & variable support

Learn more

→

[View X & Y offsets for shadows & variable support](https://webflow.com/updates/x-y-offsets-for-shadows-variable-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/656dfe6df1fce101a3fdd5d9_Prop%20organization.webp)

Enhancement

Layout & design

## Reorder your component properties

Learn more

→

[View Reorder your component properties](https://webflow.com/updates/reorder-your-component-properties)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651df8579c211dc2a1cc8544_Components.jpg)

Enhancement

Layout & design

## Build seamlessly with components usability improvements

Learn more

→

[View Build seamlessly with components usability improvements](https://webflow.com/updates/component-ux)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651df77026163687bdd66e84_Variables.jpg)

Feature

Layout & design

## Codify your design system with variables

Learn more

→

[View Codify your design system with variables](https://webflow.com/updates/variables)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651df6ce2abe644937e87063_Aspect%20ratio.jpg)

Feature

Layout & design

## Control the aspect ratios of your design elements

Learn more

→

[View Control the aspect ratios of your design elements](https://webflow.com/updates/aspect-ratio)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651df5a00e471d05c6a8c39c_Spline.jpg)

Feature

Layout & design

## Add 3D Spline scenes to your site

Learn more

→

[View Add 3D Spline scenes to your site](https://webflow.com/updates/spline)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651ded511100a35299e3dd26_New%20Designer.jpg)

Update

Layout & design

## Introducing a new look and feel to Webflow

Learn more

→

[View Introducing a new look and feel to Webflow](https://webflow.com/updates/webflow-redesign)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d692_SYBG_ArchiveWorkspace_2400x1400.jpg)

Enhancement

Layout & design

## Archive a Workspace to remove it from your Dashboard

Learn more

→

[View Archive a Workspace to remove it from your Dashboard](https://webflow.com/updates/archive-workspace)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d678_SYBG_CMSCollectionItemComponents_2400x1400%20(1).jpg)

Enhancement

Layout & design

## Components can now be used in Collection Lists

Learn more

→

[View Components can now be used in Collection Lists](https://webflow.com/updates/components-in-collection-lists)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d66c_23008_07_SYGB_Double_Click_2400x1400.jpg)

Update

Layout & design

## Usability update to components

Learn more

→

[View Usability update to components](https://webflow.com/updates/improvements-to-components)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d66b_SYGB_StrokeText_2400x1400.png)

Feature

Layout & design

## Introducing text stroke styling

Learn more

→

[View Introducing text stroke styling](https://webflow.com/updates/introducing-text-stroke-styling)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d667_VH%20vs%20DVH.png)

Enhancement

Layout & design

## Support for new CSS dynamic viewport units

Learn more

→

[View Support for new CSS dynamic viewport units](https://webflow.com/updates/support-for-new-css-dynamic-viewport-units)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d663_dotlottie.gif)

Enhancement

Layout & design

## dotLottie animation file support

Learn more

→

[View dotLottie animation file support](https://webflow.com/updates/dotlottie-animation-file-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d630_SYBG-PlayPause-2400x1400.jpg)

Enhancement

Layout & design

## Natively customize background videos with pause/play button

Learn more

→

[View Natively customize background videos with pause/play button](https://webflow.com/updates/natively-customize-background-videos-with-pause-play-button)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d62d_t3-release-sybg-updates-social-audit-panel-duplicate-id-attribute-final-2400x2400.jpg)

Enhancement

Layout & design

## Detect repetitive IDs within the elements of your website

Learn more

→

[View Detect repetitive IDs within the elements of your website](https://webflow.com/updates/detect-repetitive-ids-within-the-elements-of-your-website)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d62a_updates.jpg)

Enhancement

Layout & design

## Apply superscript or subscript formatting to your text

Learn more

→

[View Apply superscript or subscript formatting to your text](https://webflow.com/updates/apply-superscript-or-subscript-formatting-to-your-text)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21cd07_Screen%20Shot%202020-01-24%20at%209.47.41%20AM.png)

Feature

Layout & design

## Control image positioning with object-position

Learn more

→

[View Control image positioning with object-position](https://webflow.com/updates/control-image-positioning-with-object-position)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c964_grid%20areas%20restaurant.jpg)

Feature

Layout & design

## Reuse grid layouts more easily with grid template areas

Learn more

→

[View Reuse grid layouts more easily with grid template areas](https://webflow.com/updates/reuse-grid-layouts-more-easily-with-grid-template-areas)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c8b1_Grid_2_0_-_Complex_grid.jpg)

Feature

Layout & design

## CSS grid: release 2.0

Learn more

→

[View CSS grid: release 2.0](https://webflow.com/updates/css-grid-release-2-0)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c8d5_center%20button%20restoration%20v1.jpg)

Update

Layout & design

## Center element button added to new style panel

Learn more

→

[View Center element button added to new style panel](https://webflow.com/updates/center-element-button-added-to-new-style-panel)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c632_Screen%20Shot%202019-01-15%20at%202.19.14%20PM.png)

Feature

Layout & design

## Position: sticky

Learn more

→

[View Position: sticky](https://webflow.com/updates/position-sticky)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c59a_Screen%20Shot%202018-10-18%20at%203.14.21%20PM.png)

Enhancement

Layout & design

## Grid now supported in symbols

Learn more

→

[View Grid now supported in symbols](https://webflow.com/updates/grid-layout-now-supported-in-symbols)

## What’s new?

But that's not all... see the latest Webflow feature releases, product improvements and bug fixes.

[View all updates](https://webflow.com/updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/675b30a1de4dc833394a1389_cta-prefooter.avif)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)

Drift Widget

Processing... please wait

Drift Widget