[Skip to main content](https://webflow.com/updates/redirect-tests-in-webflow-optimize#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

Sign up - Webflow

[Go to Webflow](https://webflow.com/)

Welcome to Webflow!

Continue

* * *

or

* * *

Sign up with GoogleSign up with Google

Sign In - Google Accounts

Sign up with GoogleSign up with Google

Signing up for a Webflow account means you agree to the [Privacy Policy](http://www.webflow.com/legal/privacy) and [Terms of Service](http://www.webflow.com/legal/terms)

Have an account? [Sign in](https://webflow.com/login)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

[update](http://www.webflow.com/updates)

Feature

Website management

# Redirect tests in Webflow Optimize

Webflow Optimize users now have the ability to conduct redirect tests.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e5a696f1b818e8ca49354f_redirect%20tests%20optimize.png)

[updates](http://www.webflow.com/updates)

→

Redirect tests in Webflow Optimize

Feature

Website management

# Redirect tests in Webflow Optimize

Webflow Optimize users now have the ability to conduct redirect tests.

In this update

[Documentation\\
\\
→](https://webflow.com/updates/redirect-tests-in-webflow-optimize#)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/redirect-tests-in-webflow-optimize&text=Redirect%20tests%20in%20Webflow%20Optimize)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/redirect-tests-in-webflow-optimize)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/redirect-tests-in-webflow-optimize&title=Redirect%20tests%20in%20Webflow%20Optimize&summary=Webflow%20Optimize%20users%20now%20have%20the%20ability%20to%20conduct%20redirect%20tests.)

### Webflow Optimize users now have the ability to conduct redirect tests.

Redirect tests allow you to split all the traffic that arrives on a certain page (the origin page) and direct some portion of it to a new page (the destination page).

When a redirect variation is triggered, the visitor is taken from the original page and sent to a new targeted web page. Redirect variations can be helpful if you're testing a full-page redesign, redirecting specific audiences to specific landing pages, or when it's more feasible to code up a new page because the changes are so drastic that they could conflict with existing experiences running on the page.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e5a5ed88d5fa15fef62ceb_AD_4nXemmqB-XnlUPkwqvcCxRv-r6E6yKzdoEW9XnlUnl4mILPHQYWFazJdmImnxjcSNPQNMmvsKGNUAKOSwM5TnPvbNZTWISDnLMnsh7kuGpWd6ZesdnFQot1W1DyqR8jxkPW9CQ5RlLA.png)

To learn more about setting up a redirect test, check out [this help article.](https://help.webflow.com/hc/en-us/articles/38336888279315)

‍

Launched on

March 27, 2025

Category

Website management

[Documentation\\
\\
→](https://webflow.com/updates/redirect-tests-in-webflow-optimize#)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/redirect-tests-in-webflow-optimize&text=Redirect%20tests%20in%20Webflow%20Optimize)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/redirect-tests-in-webflow-optimize)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/redirect-tests-in-webflow-optimize&title=Redirect%20tests%20in%20Webflow%20Optimize&summary=Webflow%20Optimize%20users%20now%20have%20the%20ability%20to%20conduct%20redirect%20tests.)

## Related updates

[Slide left\\
\\
←](https://webflow.com/updates/redirect-tests-in-webflow-optimize#) [Slide right\\
\\
→](https://webflow.com/updates/redirect-tests-in-webflow-optimize#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67f98d97cd9cebaaa1014085_Blog_2400x1260_Average%20fold.jpg)

Feature

Website management

## New features in Webflow Analyze

Learn more

→

[View New features in Webflow Analyze](https://webflow.com/updates/new-features-in-webflow-analyze)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67d0b0ff27c2d40a401166f2_PerPageJSCSS_1280x720.jpg)

Enhancement

Website management

## Per page JavaScript

Learn more

→

[View Per page JavaScript](https://webflow.com/updates/per-page-javascript)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67a38907cb45a4486e3fe8d8_OptimizeOverview.png)

Feature

Website management

## New features for Optimize Enterprise

Learn more

→

[View New features for Optimize Enterprise](https://webflow.com/updates/new-features-for-optimize-enterprise)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/678dcaa407aa363b4c503593_Updates-thumbnail_1280x720_winter-release_1.jpg)

Feature

Website management

## Webflow Enterprise Winter Release

Learn more

→

[View Webflow Enterprise Winter Release](https://webflow.com/updates/webflow-enterprise-winter-release-2025)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6763118093752082ea457155_click%20goals.png)

Feature

Website management

## Click Goals for Webflow Optimize

Learn more

→

[View Click Goals for Webflow Optimize](https://webflow.com/updates/click-goals-for-webflow-optimize)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/675fb4377d8c306b663ee989_SlashUpdates_1280x720_well-known.jpg)

Enhancement

Website management

## Expanded .well-known file support

Learn more

→

[View Expanded .well-known file support](https://webflow.com/updates/expanded-well-known-file-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/675a2a5546c2b7ee47917b7c_sortgtmasset.png)

Enhancement

Website management

## Dashboard sorting enhancements

Learn more

→

[View Dashboard sorting enhancements](https://webflow.com/updates/dashboard-site-sorting-enhancements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e9bab41f9487224684f4b_Analyze_1920x1080.jpg)

Feature

Website management

## Webflow Analyze is now available

Learn more

→

[View Webflow Analyze is now available](https://webflow.com/updates/webflow-analyze-is-now-available)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/671fa719502da91ea3ce7212_Analyze_Updates_1280x720.png)

Feature

Website management

## Webflow Analyze rolling out now

Learn more

→

[View Webflow Analyze rolling out now](https://webflow.com/updates/analyze-rolling-out-now)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e933b2198681ef445985a_AI-assistant_Updates_1280x720.png)

Beta

Website management

## Introducing the Webflow AI Assistant

Learn more

→

[View Introducing the Webflow AI Assistant](https://webflow.com/updates/webflow-ai-assistant)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670d361a85555dd1a31cd68e_optimize1.gif)

Feature

Website management

## Maximize conversions with Webflow Optimize

Learn more

→

[View Maximize conversions with Webflow Optimize](https://webflow.com/updates/maximize-conversions-with-webflow-optimize)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e9bab41f9487224684f4b_Analyze_1920x1080.jpg)

Feature

Website management

## Introducing Webflow Analyze

Learn more

→

[View Introducing Webflow Analyze](https://webflow.com/updates/introducing-webflow-analyze)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66902f04f24a2c359968448b_SlashUpdates-HSTS-v3_1280x720.webp)

Enhancement

Website management

## HSTS response header

Learn more

→

[View HSTS response header](https://webflow.com/updates/hsts)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/667b02a348c6b82896d63148_option%202.png)

Enhancement

Website management

## Streamline your 301 redirect management with CSV support

Learn more

→

[View Streamline your 301 redirect management with CSV support](https://webflow.com/updates/301-redirect-management)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/667f2e827c5c72954b9744a4_SlashUpdates_1280x720_Usage%20dashboard.jpg)

Feature

Website management

## Usage Dashboard

Learn more

→

[View Usage Dashboard](https://webflow.com/updates/usage-dashboard)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66638c4ad584c2442449526d_Account%20Recovery.webp)

Enhancement

Website management

## Secondary email for account recovery

Learn more

→

[View Secondary email for account recovery](https://webflow.com/updates/secondary-email-for-account-recovery)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/666878bdcefcf66fbaa400d9_SCIMSSO_Updates_1280x720%402x.jpg)

Enhancement

Website management

## Automated JIT provisioning and SCIM deprovisioning on Webflow Enterprise

Learn more

→

[View Automated JIT provisioning and SCIM deprovisioning on Webflow Enterprise](https://webflow.com/updates/scim-automated-deprovisioning)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a36b3de42689f3585f24_SlashUpdates_1280x720_apple-well-known.jpg)

Feature

Website management

## Apple Well Known files in Webflow

Learn more

→

[View Apple Well Known files in Webflow](https://webflow.com/updates/apple-well-known-files-in-webflow)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651e025318c50f92e19612a1_SlashUpdates_TransferSitePlan_2400x1400.jpeg)

Enhancement

Website management

## Transfer Site plans from one site to another

Learn more

→

[View Transfer Site plans from one site to another](https://webflow.com/updates/transfer-site-plans)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d68e_Site%20Activity%20Log%20for%20Content%20Editors_1500x1500_Social.jpg)

Enhancement

Website management

## Site Activity logs for Content Editors

Learn more

→

[View Site Activity logs for Content Editors](https://webflow.com/updates/site-activity-log-for-content-editors)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d67e_23008_16_Creator_Credits_SYBG_2400x1400_1.jpg)

Feature

Website management

## Showcase projects from a client’s Workspace

Learn more

→

[View Showcase projects from a client’s Workspace](https://webflow.com/updates/creator-credits)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d676_SYBG_RemoveYourselfFromAWorkspace_2400x1400%20(1).jpg)

Feature

Website management

## Remove yourself from a Workspace

Learn more

→

[View Remove yourself from a Workspace](https://webflow.com/updates/remove-yourself-from-workspace)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d672_SYBG_Designer_Performance_Updates_2023-05_2400x1260.jpg)

Enhancement

Website management

## Performance improvements in the Designer for large websites

Learn more

→

[View Performance improvements in the Designer for large websites](https://webflow.com/updates/designer-performance-improvements-at-scale)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d666_SAL-Filters_SYBG-Header_2400x1400.png)

Enhancement

Website management

## Find what you’re looking for faster in the Site Activity log with filters

Learn more

→

[View Find what you’re looking for faster in the Site Activity log with filters](https://webflow.com/updates/site-activity-log-filters)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d65e_sybg-updates-workspace-URL.jpg)

Update

Website management

## Choose your Workspace profile URL

Learn more

→

[View Choose your Workspace profile URL](https://webflow.com/updates/choose-your-workspace-profile-url)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d65a_SYBG_SetDefaultWorkspace_2023-01%20(1).png)

Feature

Website management

## Set a default Workspace to open your dashboard to the right place

Learn more

→

[View Set a default Workspace to open your dashboard to the right place](https://webflow.com/updates/set-a-default-workspace)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d654_sybg-Page-Branching-2400x1400.jpg)

Enhancement

Website management

## Bringing more power, control, and visibility to page branching

Learn more

→

[View Bringing more power, control, and visibility to page branching](https://webflow.com/updates/page-branching-enhancements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d61e_activity-log_sybg-updates.jpg)

Feature

Website management

## Fix site issues faster and track important design changes with the Site Activity log

Learn more

→

[View Fix site issues faster and track important design changes with the Site Activity log](https://webflow.com/updates/site-activity-log)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21ca2b_Screen%20Shot%202019-09-03%20at%2010.54.19%20AM.png)

Enhancement

Website management

## Search in the asset manager

Learn more

→

[View Search in the asset manager](https://webflow.com/updates/search-in-the-asset-manager)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c991_Screen%20Shot%202019-06-13%20at%2010.24.08%20AM.png)

Enhancement

Website management

## Share a read-only link of your project from the Designer

Learn more

→

[View Share a read-only link of your project from the Designer](https://webflow.com/updates/share-a-read-only-link-of-your-project-from-the-designer)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c8db_Screen%20Shot%202019-04-09%20at%205.28.44%20PM.png)

Enhancement

Website management

## Include project settings when duplicating sites

Learn more

→

[View Include project settings when duplicating sites](https://webflow.com/updates/include-project-settings-when-duplicating-sites)

## What’s new?

But that's not all... see the latest Webflow feature releases, product improvements and bug fixes.

[View all updates](https://webflow.com/updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/675b30a1de4dc833394a1389_cta-prefooter.avif)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)

Drift Widget

Drift Widget