[Discover everything we launched at Webflow Conf 2024\\
\\
Read post\\
\\
↗](https://webflow.com/blog/webflow-conf-2024-keynote-recap)

[Skip to main content](https://webflow.com/updates?5ae0b617_page=2#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

Sign up - Webflow

[Go to Webflow](https://webflow.com/)

Welcome to Webflow!

Continue

* * *

or

* * *

Sign up with GoogleSign up with Google

Sign In - Google Accounts

Sign up with GoogleSign up with Google

Signing up for a Webflow account means you agree to the [Privacy Policy](http://www.webflow.com/legal/privacy) and [Terms of Service](http://www.webflow.com/legal/terms)

Have an account? [Sign in](https://webflow.com/login)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

# Updates

See the latest Webflow feature releases, product improvements, and bug fixes.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67bfc8cce414784070a36cd3_AISB_SlashUpdates_1280x720.png)

Beta

Designer

## Introducing Webflow's AI Site Builder

Bring the vision for your site to life in minutes — no code required.

Learn more

→

[View Introducing Webflow's AI Site Builder](https://webflow.com/updates/ai-site-builder)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/679953852d22481a60e5e63f_Slash-Updates_Client-Payments_1280x720%20(1).jpg)

Feature

Collaboration

## Client payments

Let clients securely pay for site plans, bandwidth, and add-ons, and transfer sites seamlessly to their Workspaces without disrupting key settings.

## Client payments

Learn more

→

[View ""](https://webflow.com/updates/client-payments)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/678dcaa407aa363b4c503593_Updates-thumbnail_1280x720_winter-release_1.jpg)

Feature

Website management

## Webflow Enterprise Winter Release

Introducing custom roles and an audit log API on Webflow Enterprise to bolster control, governance, and security for professional web teams.

## Webflow Enterprise Winter Release

Learn more

→

[View ""](https://webflow.com/updates/webflow-enterprise-winter-release-2025)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67869b027d1a9d44c7ab9b76_SlashUpdates_1280x720_Variable%20Modes.jpg)

Feature

Designer

## Introducing variable modes

Create sets of variable values that can be easily switched and applied throughout your site –unlocking responsive design across devices, efficient theming, and a more scalable design system.

## Introducing variable modes

Learn more

→

[View ""](https://webflow.com/updates/variable-modes)

# Updates

See the latest Webflow feature releases, product improvements and bug fixes.

No items found.

## Tiny but mighty updates

[Slide left\\
\\
←](https://webflow.com/updates?5ae0b617_page=2#) [Slide right\\
\\
→](https://webflow.com/updates?5ae0b617_page=2#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/680146ee317081bff30c3eb0_SlashUpdates_1280x720%201.png)

Enhancement

Localization

## Unifying Localization Language Settings

Learn more

→

[View Unifying Localization Language Settings](https://webflow.com/updates/unifying-localization-language-settings)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/680017af695d6d68bc9f7899_Emojis.jpg)

Feature

Collaboration

## Comments enhancements: emojis, direct links, and more

Learn more

→

[View Comments enhancements: emojis, direct links, and more](https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67ffb6ff6e19d3de9acb7b8c_SlashUpdates_Blog_2400x1260_Shared-Libraries-dashboard.jpg)

Feature

Designer

## Centrally manage your Shared Libraries

Learn more

→

[View Centrally manage your Shared Libraries](https://webflow.com/updates/centrally-manage-your-shared-libraries)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67f98d97cd9cebaaa1014085_Blog_2400x1260_Average%20fold.jpg)

Feature

Website management

## New Features in Webflow Analyze

Learn more

→

[View New features in Webflow Analyze](https://webflow.com/updates/new-features-in-webflow-analyze)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67f81668262cd6a724a2df4d_SlashUpdates_1280x720.png)

Feature

Localization

## Localization Hreflang Settings

Learn more

→

[View Localization Hreflang Settings](https://webflow.com/updates/localization-hreflang-settings)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e5a696f1b818e8ca49354f_redirect%20tests%20optimize.png)

Feature

Website management

## Redirect tests in Webflow Optimize

Learn more

→

[View Redirect tests in Webflow Optimize](https://webflow.com/updates/redirect-tests-in-webflow-optimize)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e45431ca330e2f6eaf4f21_SlashUpdates_1280x720.webp)

Enhancement

Layout & design

## Truncate long content with text overflow

Learn more

→

[View Truncate long content with text overflow](https://webflow.com/updates/truncate-content-text-overflow)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e1daa779a32a365be963ec_SlashUpdates_1280x720.jpg)

Enhancement

Collaboration

## New custom roles permissions for variables, classes, and page building

Learn more

→

[View New custom roles permissions](https://webflow.com/updates/new-custom-roles-permissions-variables-classes-page-building)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67dc67b5430048c2a42518d6_SlashUpdates_1280x720.jpg)

Enhancement

Collaboration

## Marketers can build pages without a template

Learn more

→

[View Marketers can build pages without a template](https://webflow.com/updates/marketers-build-pages-without-template)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67dc276c1539fae7ceb1055a_CMS-Content-Delivery-API_SlashUpdates_1280x720.png)

Feature

CMS

## New CMS APIs for multi-channel content delivery

Learn more

→

[View New CMS APIs for multi-channel content delivery](https://webflow.com/updates/new-cms-apis-for-multi-channel-content-delivery)

Enhancement

Collaboration

[**Localized page branching is now available**](https://webflow.com/updates/localized-page-branching)

March 20, 2024

URL copied!

[![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a82aee0f8abb4cef7780_SlashUpdates_1280x720_page-branching.webp)](https://webflow.com/updates/localized-page-branching)[Play\\
\\
Play video\\
\\
![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a82aee0f8abb4cef7780_SlashUpdates_1280x720_page-branching.webp)](https://webflow.com/updates?5ae0b617_page=2#)

Collaborate safely and efficiently on your localized sites with page branching, now fully integrated with Localization.

[Learn more\\
\\
→](https://webflow.com/updates/localized-page-branching)

Enhancement

Localization

[**Add custom images to your locale switcher without writing code**](https://webflow.com/updates/customize-your-locale-switcher-with-images)

March 13, 2024

URL copied!

[![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65f1c9a18e4ebf897ead82bb_blog%20hero.jpg)](https://webflow.com/updates/customize-your-locale-switcher-with-images)[Play\\
\\
Play video\\
\\
![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65f1c9a18e4ebf897ead82bb_blog%20hero.jpg)](https://webflow.com/updates?5ae0b617_page=2#)

You can now seamlessly incorporate images in your locale switcher –like country flags or bespoke icons– without writing code.

[Learn more\\
\\
→](https://webflow.com/updates/customize-your-locale-switcher-with-images)

Enhancement

Integrations

[**Improved API token management**](https://webflow.com/updates/api-keys)

March 8, 2024

URL copied!

[![](https://webflow.com/updates?5ae0b617_page=2)](https://webflow.com/updates/api-keys)[Play\\
\\
Play video\\
\\
![](https://webflow.com/updates?5ae0b617_page=2)](https://webflow.com/updates?5ae0b617_page=2#)

We’ve made it easier to securely create and manage your Webflow API tokens with the introduction of scoped tokens, the ability to name your API tokens for easy reference, and the ability to generate multiple tokens per site.

‍

[Learn more\\
\\
→](https://webflow.com/updates/api-keys)

Enhancement

Designer

[**Easier ways to display code in rich text elements or fields and updates to ordered lists.**](https://webflow.com/updates/display-code-on-your-website-without-writing-code-and-updates-to-ordered-lists)

March 7, 2024

URL copied!

[![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65ea1bb287e6aee5108d7b7e_Dashboard%20(8).webp)](https://webflow.com/updates/display-code-on-your-website-without-writing-code-and-updates-to-ordered-lists)[Play\\
\\
Play video\\
\\
![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65ea1bb287e6aee5108d7b7e_Dashboard%20(8).webp)](https://webflow.com/updates?5ae0b617_page=2#)

Easier ways to display code in rich text elements or fields and updates to ordered lists.

[Learn more\\
\\
→](https://webflow.com/updates/display-code-on-your-website-without-writing-code-and-updates-to-ordered-lists)

Enhancement

Designer

[**Introducing enhanced Layout controls of the Style Panel**](https://webflow.com/updates/style-panel-layout-improvements)

March 4, 2024

URL copied!

[![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65de054a8465b69c31f45c57_Thumbnail_layout-section.jpg)](https://webflow.com/updates/style-panel-layout-improvements)[Play\\
\\
Play video\\
\\
![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65de054a8465b69c31f45c57_Thumbnail_layout-section.jpg)](https://webflow.com/updates?5ae0b617_page=2#)

Explore the next level of design flexibility with our upgraded Style Panel layout controls. Start crafting more intuitive and powerful web layouts with ease from March 4th, 2024.

[Learn more\\
\\
→](https://webflow.com/updates/style-panel-layout-improvements)

Enhancement

Integrations

[**Sync your design system from Figma to Webflow with new App**](https://webflow.com/updates/figma-to-webflow-app)

February 22, 2024

URL copied!

[![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65d769aef84d5872c5946125_FigmaToWebflow_2400x1260.jpg)](https://webflow.com/updates/figma-to-webflow-app)[Play\\
\\
Play video\\
\\
![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65d769aef84d5872c5946125_FigmaToWebflow_2400x1260.jpg)](https://webflow.com/updates?5ae0b617_page=2#)

Elevate your Figma to Webflow workflow with our Companion App and Design System Sync—making your design transfers smoother and your project launches faster than ever before.

[Learn more\\
\\
→](https://webflow.com/updates/figma-to-webflow-app)

[Previous](https://webflow.com/updates?5ae0b617_page=1) [Next](https://webflow.com/updates?5ae0b617_page=3)

[Show more](https://webflow.com/updates?5ae0b617_page=2&page=2)

# Still need help?

![](https://dhygzobemt712.cloudfront.net/Icons/Light/64px/TeamContent.svg)

### Join the forum

Explore solutions, ask questions, and learn from other Webflow users.

Visit forum

↗

![](https://dhygzobemt712.cloudfront.net/Icons/Light/64px/University.svg)

### Webflow University

Learn web design and development with free courses, interactive learning, and in-depth documentation.

Explore courses

↗

## Get started for free

Try Webflow for as long as you like with our free Starter plan. Purchase a paid Site plan to publish, host, and unlock additional features.

[Get started — it's free](https://webflow.com/dashboard/signup)

Transforming the design process at

![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d3c_Logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d3b_Logo%20(1).svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d3e_Name%3DBBDO%2C%20Mode%3DLight.svg)![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d3f_Name%3Dideo%2C%20Mode%3DLight.svg)![Upwork](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/65198855c9eeec6fbadc2b25_upwork.svg)![Orangetheory Fitness](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/6751e9e97822551f0e38e7cf_orangetheory.svg)![Greenhouse](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d3d_Logo%20(2).svg)![NCR](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d36_NCR.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d39_Ted.svg)![Dropbox](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d37_Dropbox.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/65198855c9eeec6fbadc2b26_TheNewYorkTimes.svg)![Discord](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/651414f2d70bcfacd7896d38_Discord.svg)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)

Drift Widget

A **B**

[To help improve our service, this chat may be monitored or recorded by us and/ or our third-party providers in accordance with our Privacy Policy.](https://urldefense.proofpoint.com/v2/url?u=https-3A__www.google.com_url-3Fq-3Dhttps-3A__us.moodmedia.com_company_privacy-2Dpolicy_-26source-3Dgmail-2Dimap-26ust-3D1707333026000000-26usg-3DAOvVaw2akWAIJA-2DJlt2yEVWDs3nS&d=DwMFaQ&c=P1Dci1wcau9HQxzdgeFbIQ&r=rziHOMaiaBdWS5d0kXlHDFO7nyxUkNHXHG1hdv1V57I&m=Q8ZFSXqTugBtYv-hHWsCvIzTI5Twnf0Ni6ODklxipU1kraP8nNJflTWdSUdMT2Wj&s=nhZ93jZ9txZk0IUr5rspgLo55hUYl25uDBYfUbpeGbg&e= "To help improve our service, this chat may be monitored or recorded by us and/ or our third-party providers in accordance with our Privacy Policy.")

Drift Widget

A **B**