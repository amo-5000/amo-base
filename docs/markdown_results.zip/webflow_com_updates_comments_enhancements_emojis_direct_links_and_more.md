[iframe](https://117237908.intellimizeio.com/storage.html)Comments enhancements: emojis, direct links, and more \| Webflow Updates

[Skip to main content](https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

[iframe](https://webflow.com/dashboard/signup-modal)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

[update](http://www.webflow.com/updates)

Feature

Collaboration

# Comments enhancements: emojis, direct links, and more

Webflow comments enhancements include emojis, direct links, and other improvements

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/680017af695d6d68bc9f7899_Emojis.jpg)

[updates](http://www.webflow.com/updates)

→

Comments enhancements: emojis, direct links, and more

Feature

Collaboration

# Comments enhancements: emojis, direct links, and more

Webflow comments enhancements include emojis, direct links, and other improvements

In this update

[Documentation\\
\\
→](https://help.webflow.com/hc/en-us/articles/33961339882131-Comments#h_01JQVJXPW5Q1V39Z512HRB7BE0)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more&text=Comments%20enhancements:%20emojis,%20direct%20links,%20and%20more)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more&title=Comments%20enhancements:%20emojis,%20direct%20links,%20and%20more&summary=Webflow%20comments%20enhancements%20include%20emojis,%20direct%20links,%20and%20other%20improvements)

Making teamwork in Webflow feel intuitive and user-friendly is one of our top priorities. We’ve shipped a few tiny but mighty enhancements to the comments experience in Webflow:

- **Share a link to a specific comment** allows you to direct teammates to specific pieces of feedback with a single click.
- **Emoji reactions** add a layer of expressiveness, speed, and clarity to every conversation.
- **Click on links in comments** and **copy-paste comment text** to make referencing assets and instructions seamless.

We hope these quality-of-life improvements will help your team communicate more clearly — and move faster together.

Launched on

April 16, 2025

Category

Collaboration

[Documentation\\
\\
→](https://help.webflow.com/hc/en-us/articles/33961339882131-Comments#h_01JQVJXPW5Q1V39Z512HRB7BE0)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more&text=Comments%20enhancements:%20emojis,%20direct%20links,%20and%20more)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more&title=Comments%20enhancements:%20emojis,%20direct%20links,%20and%20more&summary=Webflow%20comments%20enhancements%20include%20emojis,%20direct%20links,%20and%20other%20improvements)

## Related updates

[Slide left\\
\\
←](https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more#) [Slide right\\
\\
→](https://webflow.com/updates/comments-enhancements-emojis-direct-links-and-more#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e1daa779a32a365be963ec_SlashUpdates_1280x720.jpg)

Enhancement

Collaboration

## New custom roles permissions

Learn more

→

[View New custom roles permissions](https://webflow.com/updates/new-custom-roles-permissions-variables-classes-page-building)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67dc67b5430048c2a42518d6_SlashUpdates_1280x720.jpg)

Enhancement

Collaboration

## Marketers can build pages without a template

Learn more

→

[View Marketers can build pages without a template](https://webflow.com/updates/marketers-build-pages-without-template)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/679953852d22481a60e5e63f_Slash-Updates_Client-Payments_1280x720%20(1).jpg)

Feature

Collaboration

## Client payments

Learn more

→

[View Client payments](https://webflow.com/updates/client-payments)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/673fd023b350d1381b37af9d_Screenshot%202024-11-21%20at%204.28.09%E2%80%AFPM.png)

Enhancement

Collaboration

## Design Approval Enhancements

Learn more

→

[View Design Approval Enhancements](https://webflow.com/updates/design-approval-enhancements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6733875bc92d0deed583eb04_SlashUpdate_Thumbnail_1280x720_page-building-component-slots.png)

Enhancement

Collaboration

## Making page building more flexible with component slots support

Learn more

→

[View Making page building more flexible with component slots support](https://webflow.com/updates/page-building-support-for-component-slots)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e911b20d0c954e3329306_Page%20bulding.jpg)

Feature

Collaboration

## Drag-and-drop page building to empower marketers to launch campaigns faster

Learn more

→

[View Drag-and-drop page building to empower marketers to launch campaigns faster](https://webflow.com/updates/page-building-on-all-plans)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e95635f5971424400a6ad_Design-Approvals_Updates_1280x720.png)

Enhancement

Collaboration

## Bringing more visibility and fine-tuning to design approvals

Learn more

→

[View Bringing more visibility and fine-tuning to design approvals](https://webflow.com/updates/design-approvals-enhancements-webflow-conf-2024)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66d87083b8a2202b982c3d75_Slash-updates-page-building_1280x720%20(1).jpg)

Feature

Collaboration

## Webflow Enterprise Summer Release: Page building and design approvals are here

Learn more

→

[View Webflow Enterprise Summer Release: Page building and design approvals are here](https://webflow.com/updates/webflow-enterprise-summer-release-2024)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6663092fb10ed1429816091b_SlashUpdates_1280x720.jpg)

Feature

Collaboration

## Build brand-consistent pages faster with page templates, plus an update on page building mode

Learn more

→

[View Build brand-consistent pages faster with page templates, plus an update on page building mode](https://webflow.com/updates/page-templates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a7c0a28a2442cee9ac67_SlashUpdates_1280x720_page-branching-2.webp)

Feature

Collaboration

## Review the Merge summary to safely merge page branches

Learn more

→

[View Review the Merge summary to safely merge page branches](https://webflow.com/updates/merge-summary)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65fb79ca1f5389d1be17473a_ssa-updates.png)

Feature

Collaboration

## Control which sites your teammates, guests, and clients can access

Learn more

→

[View Control which sites your teammates, guests, and clients can access](https://webflow.com/updates/site-specific-access)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a82aee0f8abb4cef7780_SlashUpdates_1280x720_page-branching.webp)

Enhancement

Collaboration

## Localized page branching

Learn more

→

[View Localized page branching](https://webflow.com/updates/localized-page-branching)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65c677cdc32a42bad7be3387_Pages%20as%20branches.webp)

Enhancement

Collaboration

## New pages as branches and edit components in branches

Learn more

→

[View New pages as branches and edit components in branches](https://webflow.com/updates/new-pages-as-branches-and-edit-components-in-branches)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65aece4e80be4b6aecb95ba2_Edit-mode-enhancements_SlashUpdates_2400x1400.png)

Enhancement

Collaboration

## Making edit mode more powerful with machine translation support

Learn more

→

[View Making edit mode more powerful with machine translation support](https://webflow.com/updates/edit-mode-enhancements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651e01f718c50f92e195cb9c_Commenter_Editor_SlashUpdates_2400x1400.jpeg)

Feature

Collaboration

## Evolving teamwork with new content editing and commenter roles

Learn more

→

[View Evolving teamwork with new content editing and commenter roles](https://webflow.com/updates/content-editing-commenter-roles)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d689_23008_22_Commenting_BlogPost1_1920x1080.jpg)

Feature

Collaboration

## Centralize feedback with commenting in the Designer

Learn more

→

[View Centralize feedback with commenting in the Designer](https://webflow.com/updates/commenting-for-workspace-members)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d64c_sybg-updates-guest-roles_2400x1400.jpg)

Feature

Collaboration

## Join your client’s Workspace for free as a guest

Learn more

→

[View Join your client’s Workspace for free as a guest](https://webflow.com/updates/agency-or-freelancer-guest)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d62b_limited%20designer%20%3Aupdate.jpeg)

Feature

Collaboration

## Invite teammates to safely build pages with existing classes and symbols

Learn more

→

[View Invite teammates to safely build pages with existing classes and symbols](https://webflow.com/updates/limited-designer-role)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d617_workspaces-blog.jpg)

Feature

Collaboration

## Teamwork simplified: Workspaces are here

Learn more

→

[View Teamwork simplified: Workspaces are here](https://webflow.com/updates/teamwork-simplified-workspaces-are-here)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d610_page-presence_graphic.jpg)

Enhancement

Collaboration

## See exactly which pages your teammates are working on in the Designer

Learn more

→

[View See exactly which pages your teammates are working on in the Designer](https://webflow.com/updates/see-which-pages-teammates-are-working-on)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d602_blog-header-image.jpg)

Feature

Collaboration

## Webflow just got a lot more collaborative

Learn more

→

[View Webflow just got a lot more collaborative](https://webflow.com/updates/webflow-just-got-a-lot-more-collaborative)

## What’s new?

But that's not all... see the latest Webflow feature releases, product improvements and bug fixes.

[View all updates](https://webflow.com/updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/675b30a1de4dc833394a1389_cta-prefooter.avif)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)

[iframe](https://js.driftt.com/core/chat?d=1&region=US&driftEnableLog=false&pageLoadStartTime=1745138959535)

[iframe](https://js.driftt.com/core?d=1&embedId=b7n85m9zerm8&eId=b7n85m9zerm8&region=US&forceShow=false&skipCampaigns=false&sessionId=9fca72cd-6e79-4b5f-a8fd-8e65e0d2606d&sessionStarted=1745138960.959&campaignRefreshToken=3e9b0321-4180-49bd-8447-b36f1c85253e&hideController=false&pageLoadStartTime=1745138959535&mode=CHAT&driftEnableLog=false&secureIframe=false&u=https%3A%2F%2Fwebflow.com%2Fupdates%2Fcomments-enhancements-emojis-direct-links-and-more)