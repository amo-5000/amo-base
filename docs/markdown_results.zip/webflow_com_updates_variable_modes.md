[Skip to main content](https://webflow.com/updates/variable-modes#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

Sign up - Webflow

[Go to Webflow](https://webflow.com/)

Welcome to Webflow!

Continue

* * *

or

* * *

Sign up with GoogleSign up with Google

Sign In - Google Accounts

Sign up with GoogleSign up with Google

Signing up for a Webflow account means you agree to the [Privacy Policy](http://www.webflow.com/legal/privacy) and [Terms of Service](http://www.webflow.com/legal/terms)

Have an account? [Sign in](https://webflow.com/login)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

[update](http://www.webflow.com/updates)

Feature

Designer

# Introducing variable modes

Create sets of variable values that can be easily switched and applied throughout your site –unlocking responsive design across devices, efficient theming, and a more scalable design system.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67869b027d1a9d44c7ab9b76_SlashUpdates_1280x720_Variable%20Modes.jpg)

[updates](http://www.webflow.com/updates)

→

Introducing variable modes

Feature

Designer

# Introducing variable modes

Create sets of variable values that can be easily switched and applied throughout your site –unlocking responsive design across devices, efficient theming, and a more scalable design system.

In this update

[Documentation\\
\\
→](https://webflow.com/updates/variable-modes#)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/variable-modes&text=Introducing%20variable%20modes)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/variable-modes)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/variable-modes&title=Introducing%20variable%20modes&summary=Create%20sets%20of%20variable%20values%20that%20can%20be%20easily%20switched%20and%20applied%20throughout%20your%20site%20%E2%80%93unlocking%20responsive%20design%20across%20devices,%20efficient%20theming,%20and%20a%20more%20scalable%20design%20system.)

[In a continued effort](https://webflow.com/updates/component-style-variants-now-available) to empower our customers with scalable design systems, we’re excited to announce the launch of variable modes, now available to all Webflow customers.

Variable modes let you define multiple values for individual variables, creating distinct sets of values (“modes”) that can be easily switched and applied across your site. This means fewer variables to create and manage, and significantly more efficient design workflows —from creating responsive designs across devices to applying different themes throughout your site.

Variable Modes from Webflow on Vimeo

![video thumbnail](https://i.vimeocdn.com/video/1970409205-3f9d5c743c0fe2c9e73d6a341615bb79f8f0abf0eaa4824a0f3815cad37951fe-d?mw=80&q=85)

Playing in picture-in-picture

More options

Like

Share

Play

Show controls

SettingsPicture-in-PictureFullscreen

[Watch on Vimeo](https://vimeo.com/)

QualityAuto

SpeedNormal

**What variable modes unlocks:**

- **Automatically responsive designs across devices.** Variable modes let you set automatically responsive variable values for Tablet, Mobile Landscape, and Mobile Portrait breakpoints. This ensures a consistent and polished experience across devices, without needing to hunt through styles or make tedious manual adjustments in each breakpoint. When you update a variable, all its breakpoint-specific values are updated globally throughout your site.

- **Streamlined theming across your site.** Variable modes make it easier than ever to create and manage different design themes for your site. For example, you can create a “Brand - Primary” theme that reflects your site’s core branding with standard colors, typography, and spacing. You can also introduce an additional mode for a “Winter Holiday” theme with more festive colors that you can apply to specific pages, sections, or elements where relevant.

- **Simplified variable management.** : As your design system expands or becomes more complex, managing variables can get overwhelming. To keep your variables and variable modes organized and easily accessible for you and your teammates, you can now add them to  different custom collections —like “Color Palettes" or “Typography”.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67868dd1ba10f1706ece0152_67868d80586ca6b2e577634e_Blog_2400x1260_Variable%2520Modes.jpeg)

[Visit our Help Center to learn how you can start designing with variable modes today.](https://help.webflow.com/hc/en-us/articles/33961268146323-Variables#h_01JHJW42D3ACWYXDTJPXV94347)

Launched on

January 14, 2025

Category

Designer

[Documentation\\
\\
→](https://webflow.com/updates/variable-modes#)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/variable-modes&text=Introducing%20variable%20modes)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/variable-modes)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/variable-modes&title=Introducing%20variable%20modes&summary=Create%20sets%20of%20variable%20values%20that%20can%20be%20easily%20switched%20and%20applied%20throughout%20your%20site%20%E2%80%93unlocking%20responsive%20design%20across%20devices,%20efficient%20theming,%20and%20a%20more%20scalable%20design%20system.)

## Related updates

[Slide left\\
\\
←](https://webflow.com/updates/variable-modes#) [Slide right\\
\\
→](https://webflow.com/updates/variable-modes#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67ffb6ff6e19d3de9acb7b8c_SlashUpdates_Blog_2400x1260_Shared-Libraries-dashboard.jpg)

Feature

Designer

## Centrally manage your Shared Libraries

Learn more

→

[View Centrally manage your Shared Libraries](https://webflow.com/updates/centrally-manage-your-shared-libraries)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67d0b0efdfcd66745458f374_SharedAssets_SlashUpdates_1280x720.jpg)

Feature

Designer

## Share assets and variable modes across your Workspace

Learn more

→

[View Share assets and variable modes across your Workspace](https://webflow.com/updates/shared-library-assets-and-variable-modes)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67bfc8cce414784070a36cd3_AISB_SlashUpdates_1280x720.png)

Beta

Designer

## Introducing Webflow's AI Site Builder

Learn more

→

[View Introducing Webflow's AI Site Builder](https://webflow.com/updates/ai-site-builder)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67a682e228e42aa2fef4464b_AI-Write-Modifications_SlashUpdates_1280x720.png)

Beta

Designer

## Webflow AI Assistant - copy modifications on canvas

Learn more

→

[View Webflow AI Assistant - copy modifications on canvas](https://webflow.com/updates/ai-assistant-quick-modifications)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/679cfc9a07cefdb657cb958d_pre-styling-OG_2400x1260.jpg)

Enhancement

Designer

## Style All <pre> Tags in Code Blocks

Learn more

→

[View Style All <pre> Tags in Code Blocks](https://webflow.com/updates/global-pre-tag-styling)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67927a18f91b1a21a3efbe89_asset-management-improvements-thumbnail.png)

Enhancement

Designer

## Asset management improvements

Learn more

→

[View Asset management improvements](https://webflow.com/updates/asset-management-improvements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6757266349869719ba27dc98_SlashUpdates_1280x720%20(2).jpg)

Enhancement

Designer

## Create components in CMS contexts

Learn more

→

[View Create components in CMS contexts](https://webflow.com/updates/create-components-in-cms-contexts)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67f6a033cdd635b5cff8bf19_AI-CopyGen-UPDATED-SlashUpdates_1280x720.webp)

Beta

Designer

## Webflow AI Assistant - copy generation on canvas

Learn more

→

[View Webflow AI Assistant - copy generation on canvas](https://webflow.com/updates/ai-assistant-content-generation)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/673bc23a00ce2c57fd8b88d6_SlashUpdates_1280x720.png)

Enhancement

Designer

## New in-product navigation

Learn more

→

[View New in-product navigation](https://webflow.com/updates/updated-navigation)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66f2bbc51d3b9dd9988d199d_SlashUpdates_1280x720.jpg)

Enhancement

Designer

## Edit components in slots

Learn more

→

[View Edit components in slots](https://webflow.com/updates/edit-components-in-slots)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66eafda7561597b819d70e45_SlashUpdates_1280x720_Rive.jpg)

Feature

Designer

## Rive support for Webflow

Learn more

→

[View Rive support for Webflow](https://webflow.com/updates/rive-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66be2fe62d03696b9ed83b7e_Slash-updates-component-prev-desc%20(1).jpg)

Enhancement

Designer

## Component previews and descriptions

Learn more

→

[View Component previews and descriptions](https://webflow.com/updates/component-previews-and-descriptions)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66aab1f93c89a45851b9a238_SlashUpdates_1280x720_Component-Groups.jpg)

Enhancement

Designer

## Organize your components

Learn more

→

[View Organize your components](https://webflow.com/updates/component-groups)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66a934c58a0549788025d4b8_SlashUpdates_1280x720_AVIF.jpg)

Enhancement

Designer

## AVIF Image Support & Conversion Tool

Learn more

→

[View AVIF Image Support & Conversion Tool](https://webflow.com/updates/avif-image-support-conversion-tool)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/669fc2c45454bccf0482d496_Webflow%20Libraries%20manage%20libraries.jpg)

Feature

Designer

## Share components and variables across sites with Libraries

Learn more

→

[View Share components and variables across sites with Libraries](https://webflow.com/updates/libraries)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6698164ccc1efc94c866b6eb_SlashUpdates_1280x720_Component%20instances.jpg)

Enhancement

Designer

## Find component instances

Learn more

→

[View Find component instances](https://webflow.com/updates/find-component-instances)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/668ea384812ee0ae837c5191_In-article-component-slots_1280x720%20v2%20(1).jpg)

Feature

Designer

## Component slots

Learn more

→

[View Component slots](https://webflow.com/updates/component-slots)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/667477678144d325b79e02b8_SlashUpdates_1280x720.png)

Enhancement

Designer

## Quickly duplicate components

Learn more

→

[View Quickly duplicate components](https://webflow.com/updates/duplicate-components)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/667218fba0577c8a4cf7d850_DesignerBasics%20(template).png)

Beta

Designer

## Learning Assistant

Learn more

→

[View Learning Assistant](https://webflow.com/updates/learning-assistant)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/663a708d63f9db814f6b310f_element%20conversion%20SlashUpdates_1280x720.webp)

Enhancement

Designer

## Extended element conversions

Learn more

→

[View Extended element conversions](https://webflow.com/updates/extended-element-conversions)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a3c00ba7d622872bff63_SlashUpdates_1280x720_Multi%20image.jpg)

Enhancement

Designer

## Single multi-image field binding for lightbox

Learn more

→

[View Single multi-image field binding for lightbox](https://webflow.com/updates/single-multi-image-field-binding-lightbox)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a64dd1ae690b64d2cec1_Class%20Attribute.webp)

Enhancement

Designer

## Add classes as custom attributes to elements

Learn more

→

[View Add classes as custom attributes to elements](https://webflow.com/updates/add-classes-as-custom-attributes-to-elements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65ea1bb287e6aee5108d7b7e_Dashboard%20(8).webp)

Enhancement

Designer

## Display code on your website without writing code & updates to ordered lists

Learn more

→

[View Display code on your website without writing code & updates to ordered lists](https://webflow.com/updates/display-code-on-your-website-without-writing-code-and-updates-to-ordered-lists)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65de054a8465b69c31f45c57_Thumbnail_layout-section.jpg)

Enhancement

Designer

## New Style panel Layout section and controls

Learn more

→

[View New Style panel Layout section and controls](https://webflow.com/updates/style-panel-layout-improvements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65d4d97fc75e526fd23df627_SlashUpdates_1280x720_Custom-properties%20(3).webp)

Feature

Designer

## Custom CSS properties and values

Learn more

→

[View Custom CSS properties and values](https://webflow.com/updates/custom-css-properties-and-values)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65c6838e55f2c55727cb1132_SlashUpdates_1280x720%20(4).webp)

Enhancement

Designer

## Custom staging domain support

Learn more

→

[View Custom staging domain support](https://webflow.com/updates/custom-staging-domain-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65a555fb836983ee8bc40b5a_Appearance%20settings.webp)

Enhancement

Designer

## Adjust appearance settings

Learn more

→

[View Adjust appearance settings](https://webflow.com/updates/adjust-appearance-settings)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65772c4d9d8e6ce6372e8b2f_Code%20block%20element%20screencap.png)

Feature

Designer

## Introducing the code block element

Learn more

→

[View Introducing the code block element](https://webflow.com/updates/introducing-the-code-block-element)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65576df2ff2c86042bff6fd5_16x9%20thumbnail.png)

Enhancement

Designer

## Prevent unwanted click and touch interactions with pointer events

Learn more

→

[View Prevent unwanted click and touch interactions with pointer events](https://webflow.com/updates/prevent-unwanted-click-and-touch-interactions-with-pointer-events)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/655646c885db28b9a0b1442b_Branch%20Staging_SlashUpdates_2400x1400%20(1).jpg)

Enhancement

Designer

## Test designs on a branch faster and safer with branch staging

Learn more

→

[View Test designs on a branch faster and safer with branch staging](https://webflow.com/updates/branch-staging)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6538559e5ec391095894f8a3_right_click.png)

Enhancement

Designer

## Right click now supported in the Navigator panel

Learn more

→

[View Right click now supported in the Navigator panel](https://webflow.com/updates/right-click-nav-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d694_SlashUpdates_2400x1400.webp)

Enhancement

Designer

## Protect your site with improved publishing workflows

Learn more

→

[View Protect your site with improved publishing workflows](https://webflow.com/updates/publishing-workflows)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d690_Screenshot.png)

Feature

Designer

## Text wrapping and Word breaking now supported

Learn more

→

[View Text wrapping and Word breaking now supported](https://webflow.com/updates/text-wrapping-and-word-breaking-now-supported)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d68c_23008_23_Publishing_Permission_Toggle_Header_2400x1400.jpg)

Enhancement

Designer

## Simplified publishing permissions with new toggle

Learn more

→

[View Simplified publishing permissions with new toggle](https://webflow.com/updates/publishing-permission-toggle)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d685_23008_21_Increased_Page_Limits_Social_2160x2160.jpg)

Update

Designer

## Unlock greater scale with increased pages

Learn more

→

[View Unlock greater scale with increased pages](https://webflow.com/updates/unlock-greater-scale-with-increased-pages)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65bbc55dc6a005e1dc6d03e3_Better%20Visibility.png)

Enhancement

Designer

## Better visibility on publishing progress

Learn more

→

[View Better visibility on publishing progress](https://webflow.com/updates/publishing-experience-improvements-at-scale)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d674_Search%20still%20(1).jpg)

Enhancement

Designer

## Quickly search for swatches in the style panel

Learn more

→

[View Quickly search for swatches in the style panel](https://webflow.com/updates/search-for-swatches)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d66a_641c82227425746f986276aa_Wrap-element-in-div-or-link-block_1.png)

Enhancement

Designer

## Shortcuts for wrapping elements in div or link blocks

Learn more

→

[View Shortcuts for wrapping elements in div or link blocks](https://webflow.com/updates/shortcuts-for-wrapping-div-or-link-blocks)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d65c_Variable%20Fonts%20Improvements%20-%20SYBG.jpg)

Feature

Designer

## Variable fonts update

Learn more

→

[View Variable fonts update](https://webflow.com/updates/variable-fonts-update)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d651_VariableFonts_Email_1200x700%402x.png)

Feature

Designer

## Variable fonts support now in beta

Learn more

→

[View Variable fonts support now in beta](https://webflow.com/updates/variable-fonts-support-now-in-beta)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d641_Components-%E2%80%93-Blog.png)

Enhancement

Designer

## "Symbols" evolved to "Components"

Learn more

→

[View "Symbols" evolved to "Components"](https://webflow.com/updates/symbols-evolved-to-components)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d63e_Page-branching-%E2%80%94-Blog.png)

Feature

Designer

## Page branching

Learn more

→

[View Page branching](https://webflow.com/updates/page-branching)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d631_sybg-text-zoom-preview-2.png)

Feature

Designer

## Natively preview layouts with any text size seamlessly in the Designer

Learn more

→

[View Natively preview layouts with any text size seamlessly in the Designer](https://webflow.com/updates/natively-preview-layouts-with-any-text-size)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d61b_css-search_sybg-updates-2400x2400.jpg)

Enhancement

Designer

## Search CSS classes in the Style Manager

Learn more

→

[View Search CSS classes in the Style Manager](https://webflow.com/updates/search-css-classes-in-the-style-manager)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d615_g-nav-ad_releases.jpeg)

Enhancement

Designer

## Preview the CSS properties of classes in the Style Manager

Learn more

→

[View Preview the CSS properties of classes in the Style Manager](https://webflow.com/updates/preview-the-css-properties-of-classes-in-the-style-manager)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d613_outlines-compressed.jpg)

Feature

Designer

## Improve keyboard navigation with outline styling and keyboard focus state

Learn more

→

[View Improve keyboard navigation with outline styling and keyboard focus state](https://webflow.com/updates/outline-styling-and-keyboard-focus-state)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d60b_backdrop%20filter3-c.jpg)

Beta

Designer

## Create blurring and color effects with backdrop filters

Learn more

→

[View Create blurring and color effects with backdrop filters](https://webflow.com/updates/backdrop-filters)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d60e_blend%20mode%20image.png)

Feature

Designer

## Control how stacked element colors blend with new blending mode

Learn more

→

[View Control how stacked element colors blend with new blending mode](https://webflow.com/updates/blending-mode)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d603_Screen%20Shot%202021-04-12%20at%2012.57.43%20PM.png)

Feature

Designer

## Focus mode in style panel

Learn more

→

[View Focus mode in style panel](https://webflow.com/updates/focus-mode-in-style-panel)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d4cc_Blog-cover_NestedSymbols.jpg)

Enhancement

Designer

## Nest symbols inside other symbols

Learn more

→

[View Nest symbols inside other symbols](https://webflow.com/updates/nest-symbols-inside-other-symbols)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d238_Screen%20Shot%202020-08-24%20at%209.51.32%20AM.png)

Update

Designer

## Symbols are now in their own panel

Learn more

→

[View Symbols are now in their own panel](https://webflow.com/updates/symbols-are-now-in-their-own-panel)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d1e2_Screen%20Shot%202020-08-11%20at%2010.41.27%20AM.png)

Enhancement

Designer

## Control width of text elements by character count using “ch” unit

Learn more

→

[View Control width of text elements by character count using “ch” unit](https://webflow.com/updates/control-width-of-text-elements-by-character-count-using-ch-unit)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d1e4_Screen%20Shot%202020-08-07%20at%2011.43.52%20AM.png)

Feature

Designer

## Fill text with gradients, images, and overlays with background clipping

Learn more

→

[View Fill text with gradients, images, and overlays with background clipping](https://webflow.com/updates/fill-text-with-gradients-images-and-overlays-with-background-clipping)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21ce6e_content-overrides-for-symbols.jpg)

Feature

Designer

## Apply content overrides for symbol instances

Learn more

→

[View Apply content overrides for symbol instances](https://webflow.com/updates/apply-content-overrides-for-symbol-instances)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21cbff_hero.jpg)

Feature

Designer

## You can now use custom code in rich text elements

Learn more

→

[View You can now use custom code in rich text elements](https://webflow.com/updates/custom-code-in-rich-text-elements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c9ef_Screen%20Shot%202019-08-22%20at%2010.04.09%20AM.png)

Feature

Designer

## White space property added to control text wrapping

Learn more

→

[View White space property added to control text wrapping](https://webflow.com/updates/white-space-property-added-to-control-text-wrapping)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c795_nav-second-screen-v1.jpg)

Update

Designer

## Navigator now on the left for everyone

Learn more

→

[View Navigator now on the left for everyone](https://webflow.com/updates/navigator-now-on-the-left-for-everyone)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c9c6_rc%20convert%20v1.jpg)

Enhancement

Designer

## Right-click to convert div blocks to link blocks

Learn more

→

[View Right-click to convert div blocks to link blocks](https://webflow.com/updates/right-click-to-convert-div-blocks-to-link-blocks)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c99a_display%20none%20indicator%20v1.jpg)

Enhancement

Designer

## Identify hidden elements more easily in navigator

Learn more

→

[View Identify hidden elements more easily in navigator](https://webflow.com/updates/identify-hidden-elements-more-easily-in-navigator)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c795_nav-second-screen-v1.jpg)

Beta

Designer

## New navigator location

Learn more

→

[View New navigator location](https://webflow.com/updates/new-navigator-location)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c86d_url%20parameter.jpg)

Enhancement

Designer

## Link to specific pages in the Designer

Learn more

→

[View Link to specific pages in the Designer](https://webflow.com/updates/link-to-specific-pages-in-the-designer)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c600_nav%20before%20and%20after%20v1.jpg)

Enhancement

Designer

## Cleaned up, more legible navigator

Learn more

→

[View Cleaned up, more legible navigator](https://webflow.com/updates/cleaned-up-more-legible-navigator)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c6ae_styles%20panel%20before%20and%20after%20v7.jpg)

Update

Designer

## We’re making some changes to the style panel

Learn more

→

[View We’re making some changes to the style panel](https://webflow.com/updates/were-making-some-changes-to-the-style-panel)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c619_Screen%20Shot%202018-11-27%20at%206.17.57%20PM.png)

Update

Designer

## Experimental support for the Designer in Firefox

Learn more

→

[View Experimental support for the Designer in Firefox](https://webflow.com/updates/experimental-support-for-the-designer-in-firefox)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c566_airpockets.jpg)

Update

Designer

## Landing page tutorial

Learn more

→

[View Landing page tutorial](https://webflow.com/updates/landing-page-tutorial)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c6d8_Screen%20Shot%202018-10-25%20at%2012.10.51%20PM.png)

Enhancement

Designer

## Drag to resize grid columns, rows, and gaps

Learn more

→

[View Drag to resize grid columns, rows, and gaps](https://webflow.com/updates/drag-to-resize-grid-columns-rows-and-gaps)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c42f_Screen%20Shot%202018-09-07%20at%209.47.22%20AM.png)

Enhancement

Designer

## Quick find

Learn more

→

[View Quick find](https://webflow.com/updates/quick-find)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c4a6_Screen%20Shot%202018-08-28%20at%203.26.21%20PM.png)

Enhancement

Designer

## Color swatches now global by default

Learn more

→

[View Color swatches now global by default](https://webflow.com/updates/color-swatches-now-global-by-default)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c37c_Add-reCAPTCHA-to-forms.gif)

Feature

Designer

## Add a reCAPTCHA field to your forms

Learn more

→

[View Add a reCAPTCHA field to your forms](https://webflow.com/updates/add-a-recaptcha-field-to-your-forms)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c241_class%20shortcut%20gif%20v5.gif)

Enhancement

Designer

## Add classes faster with a keyboard shortcut

Learn more

→

[View Add classes faster with a keyboard shortcut](https://webflow.com/updates/add-classes-faster-with-a-keyboard-shortcut)

## What’s new?

But that's not all... see the latest Webflow feature releases, product improvements and bug fixes.

[View all updates](https://webflow.com/updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/675b30a1de4dc833394a1389_cta-prefooter.avif)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)

Drift Widget

Processing... please wait

Drift Widget