[Skip to main content](https://webflow.com/updates/figma-to-webflow-app#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

Sign up - Webflow

[Go to Webflow](https://webflow.com/)

Welcome to Webflow!

Continue

* * *

or

* * *

Sign up with GoogleSign up with Google

Sign In - Google Accounts

Sign up with GoogleSign up with Google

Signing up for a Webflow account means you agree to the [Privacy Policy](http://www.webflow.com/legal/privacy) and [Terms of Service](http://www.webflow.com/legal/terms)

Have an account? [Sign in](https://webflow.com/login)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

[update](http://www.webflow.com/updates)

Enhancement

Integrations

# Figma to Webflow App

Launch Webflow sites faster with the new companion App & Design System Sync for Figma. Seamless syncing, enhanced control, and easy design transfer.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65d769aef84d5872c5946125_FigmaToWebflow_2400x1260.jpg)

[updates](http://www.webflow.com/updates)

→

Figma to Webflow App

Enhancement

Integrations

# Figma to Webflow App

Launch Webflow sites faster with the new companion App & Design System Sync for Figma. Seamless syncing, enhanced control, and easy design transfer.

In this update

[Documentation\\
\\
→](https://university.webflow.com/courses/figma-to-webflow)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/figma-to-webflow-app&text=Figma%20to%20Webflow%20App)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/figma-to-webflow-app)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/figma-to-webflow-app&title=Figma%20to%20Webflow%20App&summary=Launch%20Webflow%20sites%20faster%20with%20the%20new%20companion%20App%20&%20Design%20System%20Sync%20for%20Figma.%20Seamless%20syncing,%20enhanced%20control,%20and%20easy%20design%20transfer.)

### Sync Figma to Webflow with new companion App

Today, we are pleased to announce the release of the companion App for the [Figma to Webflow plugin](https://www.figma.com/community/plugin/1164923964214525039) and a new capability we’re calling Design System Sync within the plugin. With this release users of the integration now have a more efficient workflow for transferring components and variables from Figma into Webflow projects.

### Key features:

- **Companion App**: Located in the Webflow Apps panel, the [companion App](https://webflow.com/apps/detail/figma-to-webflow) enhances the existing plugin by facilitating a direct sync to Webflow.
- **Design System Sync tab**: New in the plugin, users can now sync components and variables from Figma with greater ease, ensuring design consistency across platforms.
- **Preview and inspect**: Within the App, users who sync updates to previously linked components or variables will see previews in the App, with the option to inspect the CSS changes as well.
- **Approval queue**: Now users in Webflow can review changes and give final approval, ensuring a higher level of control and accuracy in the deployment of designs to the web.

These enhancements are designed to integrate seamlessly into your existing workflow, minimizing disruptions and maximizing productivity. With a more controlled and efficient bridge between Figma designs and Webflow projects, the App, sync, and approvals reduces the manual effort required in the design-to-code transition.

Design System Sync (Figma to Webflow) from Webflow Labs - YouTube

Webflow

211K subscribers

[Design System Sync (Figma to Webflow) from Webflow Labs](https://www.youtube.com/watch?v=hVRzm9kZ8jQ)

Webflow

Search

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

Watch later

Share

Copy link

Watch on

0:00

/ •Live

•

[Watch on YouTube](https://www.youtube.com/watch?v=hVRzm9kZ8jQ "Watch on YouTube")

‍

### Empowering design systems

The new companion App and Design System Sync enhance Webflow by ensuring seamless, [scalable design systems](https://webflow.com/blog/announcing-figma-webflow-design-system-sync). This means consistent, efficient design-to-code workflows, unblocking users to focus more on creativity and the business critical maintenance of a unified design language.

### Getting started

The App is included with the plugin upon installation from the [Figma Community listing](https://www.figma.com/community/plugin/1164923964214525039). For those who already have the plugin installed, the App will become available upon the next plugin authentication or login. After confirming you have the latest version of the plugin, access the companion App through the [Apps panel](https://university.webflow.com/lesson/webflow-apps-overview?topics=getting-started#how-to-use-apps-in-the-designer) within your Webflow project. Then from within Figma, use the plugin to begin your first sync. Soon you’ll be on your way to designing in Figma and launching in Webflow.

### Sync your designs today

Add the [Figma to Webflow plugin](https://www.figma.com/community/plugin/1164923964214525039) to your Webflow project; the App, and Design System Sync, come included.

One year and over 180,000 installs since the launch of the plugin, today’s release of the companion App and Design System Sync will unlock even more possibilities. Thanks for being with us. We can’t wait to see what you build next.

Launched on

February 22, 2024

Category

Integrations

[Documentation\\
\\
→](https://university.webflow.com/courses/figma-to-webflow)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/figma-to-webflow-app&text=Figma%20to%20Webflow%20App)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/figma-to-webflow-app)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/figma-to-webflow-app&title=Figma%20to%20Webflow%20App&summary=Launch%20Webflow%20sites%20faster%20with%20the%20new%20companion%20App%20&%20Design%20System%20Sync%20for%20Figma.%20Seamless%20syncing,%20enhanced%20control,%20and%20easy%20design%20transfer.)

## Related updates

[Slide left\\
\\
←](https://webflow.com/updates/figma-to-webflow-app#) [Slide right\\
\\
→](https://webflow.com/updates/figma-to-webflow-app#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67a198a939e92273dd79bbc1_f2w-thumbnail.png)

Enhancement

Integrations

## Major Figma to Webflow improvements

Learn more

→

[View Major Figma to Webflow improvements](https://webflow.com/updates/major-figma-to-webflow-improvements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6759c119103daa33e31ec6de_SlashUpdates_1280x720.png)

Feature

Integrations

## Optimize Enterprise data integrations

Learn more

→

[View Optimize Enterprise data integrations](https://webflow.com/updates/optimize-integrations)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66fee46a8cf735b87fb766e1_SlashUpdates_1280x720.png)

Enhancement

Integrations

## Simplified Figma to Webflow Sync

Learn more

→

[View Simplified Figma to Webflow Sync](https://webflow.com/updates/simplified-figma-to-webflow-sync)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66bcf86d7665872e36302a8f_SlashUpdates%20Figma%20to%20Webflow%20(1).jpg)

Enhancement

Integrations

## Figma to Webflow improvements

Learn more

→

[View Figma to Webflow improvements](https://webflow.com/updates/figma-to-webflow-improvements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a46b7a30e2733c8c90a5_SlashUpdates_1280x720_F2W%20Unit%20support.jpg)

Enhancement

Integrations

## Support for Rem and Em units in Figma to Webflow sync

Learn more

→

[View Support for Rem and Em units in Figma to Webflow sync](https://webflow.com/updates/support-for-rem-and-em-units-in-figma-to-webflow-sync)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651df8d513b882d4e3adffea_APIs.jpg)

Update

Integrations

## New APIs: Component, Variables and Localization

Learn more

→

[View New APIs: Component, Variables and Localization](https://webflow.com/updates/api-updates-q323)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d699_SYBG_ArchiveWorkspace_2400x1400.jpg)

Update

Integrations

## Updates to our Developer Platform

Learn more

→

[View Updates to our Developer Platform](https://webflow.com/updates/developer-platform-updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d684_23008_19_DevLinkOpenBeta_SYBG_2400x1400.jpg)

Beta

Integrations

## DevLink open beta

Learn more

→

[View DevLink open beta](https://webflow.com/updates/devlink-open-beta)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d67d_23008_17_Figma_Combo_Class_SYBG_2400x1400.jpg)

Enhancement

Integrations

## Combo class support for Figma plugin

Learn more

→

[View Combo class support for Figma plugin](https://webflow.com/updates/figma-combo-class-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d644_Developer-resources-%E2%80%94-Blog.png)

Update

Integrations

## Developer resources

Learn more

→

[View Developer resources](https://webflow.com/updates/developer-resources)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d608_Hubspot-integration_Email_JV-compressed.png)

Feature

Integrations

## Connect your forms directly to HubSpot

Learn more

→

[View Connect your forms directly to HubSpot](https://webflow.com/updates/hubspot-integration)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d601_Marketo-integration%20graphic.png)

Feature

Integrations

## Connect your forms directly to Marketo

Learn more

→

[View Connect your forms directly to Marketo](https://webflow.com/updates/marketo-integration)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c7e1_optimize.jpg)

Feature

Integrations

## Google Optimize integration

Learn more

→

[View Google Optimize integration](https://webflow.com/updates/google-optimize-integration)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c76c_Screen%20Shot%202018-11-05%20at%208.05.39%20PM.png)

Feature

Integrations

## More controls for YouTube embeds

Learn more

→

[View More controls for YouTube embeds](https://webflow.com/updates/more-controls-for-youtube-embeds)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c465_Screen%20Shot%202018-09-05%20at%2011.06.02%20AM.png)

Feature

Integrations

## Facebook pixel integration

Learn more

→

[View Facebook pixel integration](https://webflow.com/updates/facebook-pixel-integration)

## What’s new?

But that's not all... see the latest Webflow feature releases, product improvements and bug fixes.

[View all updates](https://webflow.com/updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/675b30a1de4dc833394a1389_cta-prefooter.avif)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)

Drift Widget

A **B**

[To help improve our service, this chat may be monitored or recorded by us and/ or our third-party providers in accordance with our Privacy Policy.](https://urldefense.proofpoint.com/v2/url?u=https-3A__www.google.com_url-3Fq-3Dhttps-3A__us.moodmedia.com_company_privacy-2Dpolicy_-26source-3Dgmail-2Dimap-26ust-3D1707333026000000-26usg-3DAOvVaw2akWAIJA-2DJlt2yEVWDs3nS&d=DwMFaQ&c=P1Dci1wcau9HQxzdgeFbIQ&r=rziHOMaiaBdWS5d0kXlHDFO7nyxUkNHXHG1hdv1V57I&m=Q8ZFSXqTugBtYv-hHWsCvIzTI5Twnf0Ni6ODklxipU1kraP8nNJflTWdSUdMT2Wj&s=nhZ93jZ9txZk0IUr5rspgLo55hUYl25uDBYfUbpeGbg&e= "To help improve our service, this chat may be monitored or recorded by us and/ or our third-party providers in accordance with our Privacy Policy.")

Drift Widget

A **B**