[Skip to main content](https://webflow.com/updates/customize-your-locale-switcher-with-images#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

Sign up - Webflow

[Go to Webflow](https://webflow.com/)

Welcome to Webflow!

Continue

* * *

or

* * *

Sign up with GoogleSign up with Google

Sign In - Google Accounts

Sign up with GoogleSign up with Google

Signing up for a Webflow account means you agree to the [Privacy Policy](http://www.webflow.com/legal/privacy) and [Terms of Service](http://www.webflow.com/legal/terms)

Have an account? [Sign in](https://webflow.com/login)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

[update](http://www.webflow.com/updates)

Enhancement

Localization

# Add custom images to your locale switcher without writing code

You can now seamlessly incorporate images in your locale switcher –like country flags or bespoke icons– without writing code.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65f1c9a18e4ebf897ead82bb_blog%20hero.jpg)

[updates](http://www.webflow.com/updates)

→

Add custom images to your locale switcher without writing code

Enhancement

Localization

# Add custom images to your locale switcher without writing code

You can now seamlessly incorporate images in your locale switcher –like country flags or bespoke icons– without writing code.

In this update

[Documentation\\
\\
→](https://university.webflow.com/lesson/build-a-locale-switcher?topics%3Dlocalization)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/customize-your-locale-switcher-with-images&text=Add%20custom%20images%20to%20your%20locale%20switcher%20without%20writing%20code)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/customize-your-locale-switcher-with-images)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/customize-your-locale-switcher-with-images&title=Add%20custom%20images%20to%20your%20locale%20switcher%20without%20writing%20code&summary=You%20can%20now%20seamlessly%20incorporate%20images%20in%20your%20locale%20switcher%20%E2%80%93like%20country%20flags%20or%20bespoke%20icons%E2%80%93%20without%20writing%20code.)

Our native locales list element lets you build a custom language switcher for your site visitors to easily navigate to their locale, and we’re happy to share that you can now dynamically bind images to each locale. This means you can seamlessly incorporate custom visuals in your language switcher –like country flags or bespoke icons– without writing code.

![A styled image of the UI where you can bind an image to your locales list element ](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65f1c9a18e4ebf897ead82bb_blog%20hero.jpg)

Seamlessly incorporate images in your locale switcher –like country flags or bespoke icons– without writing code.

Learn more about how to build a custom language switcher at [Webflow University.](https://university.webflow.com/lesson/build-a-locale-switcher?topics=localization)

If you’re interested in adding Localization to your site, [compare plans here](https://webflow.com/localization#localization-pricing).

Launched on

March 13, 2024

Category

Localization

[Documentation\\
\\
→](https://university.webflow.com/lesson/build-a-locale-switcher?topics%3Dlocalization)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/customize-your-locale-switcher-with-images&text=Add%20custom%20images%20to%20your%20locale%20switcher%20without%20writing%20code)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/customize-your-locale-switcher-with-images)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/customize-your-locale-switcher-with-images&title=Add%20custom%20images%20to%20your%20locale%20switcher%20without%20writing%20code&summary=You%20can%20now%20seamlessly%20incorporate%20images%20in%20your%20locale%20switcher%20%E2%80%93like%20country%20flags%20or%20bespoke%20icons%E2%80%93%20without%20writing%20code.)

## Related updates

[Slide left\\
\\
←](https://webflow.com/updates/customize-your-locale-switcher-with-images#) [Slide right\\
\\
→](https://webflow.com/updates/customize-your-locale-switcher-with-images#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/680146ee317081bff30c3eb0_SlashUpdates_1280x720%201.png)

Enhancement

Localization

## Unifying Localization Language Settings

Learn more

→

[View Unifying Localization Language Settings](https://webflow.com/updates/unifying-localization-language-settings)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67f81668262cd6a724a2df4d_SlashUpdates_1280x720.png)

Feature

Localization

## Localization Hreflang Settings

Learn more

→

[View Localization Hreflang Settings](https://webflow.com/updates/localization-hreflang-settings)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67a4d3ce5197cb13d4842568_SlashUpdates_1280x720_Draft-pages-per-locale.jpg)

Enhancement

Localization

## Draft individual static pages per locale

Learn more

→

[View Draft individual static pages per locale](https://webflow.com/updates/draft-individual-static-pages-per-locale)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e008cbddad1f1cfdda60d_Localization_Updates_1280x720.png)

Update

Localization

## Localized styles unlocked for all customers, plus more

Learn more

→

[View Localized styles unlocked for all customers, plus more](https://webflow.com/updates/localized-styles-available-for-all-customers)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a3a90509c90f95b4f2b8_SlashUpdates_1280x720_glossary.jpg)

Feature

Localization

## Machine translation glossary available for Enterprise Localization

Learn more

→

[View Machine translation glossary available for Enterprise Localization](https://webflow.com/updates/machine-translation-glossary)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65651040a5fb691288f01f76_Updates_Localization_2400x1400%20(1).jpg)

Feature

Localization

## Localization available now for all customers

Learn more

→

[View Localization available now for all customers](https://webflow.com/updates/localization-available-now-for-all-customers)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65555ec180ceb769fa2d8cff_01%20-%20Vlad%20Localization%20image_2400x1400.png)

Feature

Localization

## Localization now rolling out for all customers

Learn more

→

[View Localization now rolling out for all customers](https://webflow.com/updates/localizationavailabilityupdate)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651df36398be3e8ae74d6a22_Localization.jpg)

Feature

Localization

## Localization now available for Enterprise

Learn more

→

[View Localization now available for Enterprise](https://webflow.com/updates/localization-enterprise-availability)

## What’s new?

But that's not all... see the latest Webflow feature releases, product improvements and bug fixes.

[View all updates](https://webflow.com/updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/675b30a1de4dc833394a1389_cta-prefooter.avif)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)

Drift Widget

Processing... please wait

Drift Widget