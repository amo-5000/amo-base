[iframe](https://117237908.intellimizeio.com/storage.html)Usage Dashboard \| Webflow Updates

[Skip to main content](https://webflow.com/updates/usage-dashboard#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

[iframe](https://webflow.com/dashboard/signup-modal)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

[update](http://www.webflow.com/updates)

Feature

Website management

# Usage Dashboard

Introducing a central place for you to get insights into the bandwidth consumption of your site.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/667f2e827c5c72954b9744a4_SlashUpdates_1280x720_Usage%20dashboard.jpg)

[updates](http://www.webflow.com/updates)

→

Usage Dashboard

Feature

Website management

# Usage Dashboard

Introducing a central place for you to get insights into the bandwidth consumption of your site.

In this update

[Documentation\\
\\
→](https://university.webflow.com/lesson/bandwidth)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/usage-dashboard&text=Usage%20Dashboard)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/usage-dashboard)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/usage-dashboard&title=Usage%20Dashboard&summary=Introducing%20a%20central%20place%20for%20you%20to%20get%20insights%20into%20the%20bandwidth%20consumption%20of%20your%20site.)

When it’s operating like a well-oiled machine, your website can become a critical driver for your business outcomes – but the impact it has also depends in big part on how things operate under the hood. Today we’re excited to release the usage dashboard, a central spot for you to track your website assets and how they’re contributing to your overall bandwidth consumption.

The heavier the assets that your site needs to render (images, videos, etc.), the more likely your site performance slows, which can cause a worse experience for visitors and, ultimately, lower engagement. That’s why it’s important to audit your assets from time to time, and make sure they’re not slowing down your page performance.

The usage dashboard helps you identify those high-consumption assets by allowing you to organize them by bandwidth, or bandwidth by asset type – so you can then take action to compress or delete assets that aren’t being used.

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/667b0e3828349b75b6f109d9_AD_4nXd3GeypLEqbOmWOP-HHhdpOVa18nqYGirgQHRNMh_5ePGoAcEDUL8GF4uA0sBODJe7Bwgukc8xTakPtGWtCDKB-x9cw--hJ1muSJuLOBz4G1ViynXwBlew1lniu_WQqNE8vFIYFP_EUSfRnPMduFhdt3iS2.png)

The usage dashboard gives you visibility into the bandwidth consumption of your site assets.

‍ **Getting Started**

To access the usage dashboard go to Site settings > Site usage. There you can use the date picker to view overall bandwidth and asset bandwidth usage over a preset or custom date range.

The usage dashboard is live to all customers today! To learn more, check out this [article](https://university.webflow.com/lesson/bandwidth).

Launched on

June 25, 2024

Category

Website management

[Documentation\\
\\
→](https://university.webflow.com/lesson/bandwidth)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/usage-dashboard&text=Usage%20Dashboard)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/usage-dashboard)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/usage-dashboard&title=Usage%20Dashboard&summary=Introducing%20a%20central%20place%20for%20you%20to%20get%20insights%20into%20the%20bandwidth%20consumption%20of%20your%20site.)

## Related updates

[Slide left\\
\\
←](https://webflow.com/updates/usage-dashboard#) [Slide right\\
\\
→](https://webflow.com/updates/usage-dashboard#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67f98d97cd9cebaaa1014085_Blog_2400x1260_Average%20fold.jpg)

Feature

Website management

## New features in Webflow Analyze

Learn more

→

[View New features in Webflow Analyze](https://webflow.com/updates/new-features-in-webflow-analyze)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67e5a696f1b818e8ca49354f_redirect%20tests%20optimize.png)

Feature

Website management

## Redirect tests in Webflow Optimize

Learn more

→

[View Redirect tests in Webflow Optimize](https://webflow.com/updates/redirect-tests-in-webflow-optimize)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67d0b0ff27c2d40a401166f2_PerPageJSCSS_1280x720.jpg)

Enhancement

Website management

## Per page JavaScript

Learn more

→

[View Per page JavaScript](https://webflow.com/updates/per-page-javascript)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67a38907cb45a4486e3fe8d8_OptimizeOverview.png)

Feature

Website management

## New features for Optimize Enterprise

Learn more

→

[View New features for Optimize Enterprise](https://webflow.com/updates/new-features-for-optimize-enterprise)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/678dcaa407aa363b4c503593_Updates-thumbnail_1280x720_winter-release_1.jpg)

Feature

Website management

## Webflow Enterprise Winter Release

Learn more

→

[View Webflow Enterprise Winter Release](https://webflow.com/updates/webflow-enterprise-winter-release-2025)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6763118093752082ea457155_click%20goals.png)

Feature

Website management

## Click Goals for Webflow Optimize

Learn more

→

[View Click Goals for Webflow Optimize](https://webflow.com/updates/click-goals-for-webflow-optimize)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/675fb4377d8c306b663ee989_SlashUpdates_1280x720_well-known.jpg)

Enhancement

Website management

## Expanded .well-known file support

Learn more

→

[View Expanded .well-known file support](https://webflow.com/updates/expanded-well-known-file-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/675a2a5546c2b7ee47917b7c_sortgtmasset.png)

Enhancement

Website management

## Dashboard sorting enhancements

Learn more

→

[View Dashboard sorting enhancements](https://webflow.com/updates/dashboard-site-sorting-enhancements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e9bab41f9487224684f4b_Analyze_1920x1080.jpg)

Feature

Website management

## Webflow Analyze is now available

Learn more

→

[View Webflow Analyze is now available](https://webflow.com/updates/webflow-analyze-is-now-available)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/671fa719502da91ea3ce7212_Analyze_Updates_1280x720.png)

Feature

Website management

## Webflow Analyze rolling out now

Learn more

→

[View Webflow Analyze rolling out now](https://webflow.com/updates/analyze-rolling-out-now)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e933b2198681ef445985a_AI-assistant_Updates_1280x720.png)

Beta

Website management

## Introducing the Webflow AI Assistant

Learn more

→

[View Introducing the Webflow AI Assistant](https://webflow.com/updates/webflow-ai-assistant)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670d361a85555dd1a31cd68e_optimize1.gif)

Feature

Website management

## Maximize conversions with Webflow Optimize

Learn more

→

[View Maximize conversions with Webflow Optimize](https://webflow.com/updates/maximize-conversions-with-webflow-optimize)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/670e9bab41f9487224684f4b_Analyze_1920x1080.jpg)

Feature

Website management

## Introducing Webflow Analyze

Learn more

→

[View Introducing Webflow Analyze](https://webflow.com/updates/introducing-webflow-analyze)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66902f04f24a2c359968448b_SlashUpdates-HSTS-v3_1280x720.webp)

Enhancement

Website management

## HSTS response header

Learn more

→

[View HSTS response header](https://webflow.com/updates/hsts)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/667b02a348c6b82896d63148_option%202.png)

Enhancement

Website management

## Streamline your 301 redirect management with CSV support

Learn more

→

[View Streamline your 301 redirect management with CSV support](https://webflow.com/updates/301-redirect-management)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66638c4ad584c2442449526d_Account%20Recovery.webp)

Enhancement

Website management

## Secondary email for account recovery

Learn more

→

[View Secondary email for account recovery](https://webflow.com/updates/secondary-email-for-account-recovery)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/666878bdcefcf66fbaa400d9_SCIMSSO_Updates_1280x720%402x.jpg)

Enhancement

Website management

## Automated JIT provisioning and SCIM deprovisioning on Webflow Enterprise

Learn more

→

[View Automated JIT provisioning and SCIM deprovisioning on Webflow Enterprise](https://webflow.com/updates/scim-automated-deprovisioning)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a36b3de42689f3585f24_SlashUpdates_1280x720_apple-well-known.jpg)

Feature

Website management

## Apple Well Known files in Webflow

Learn more

→

[View Apple Well Known files in Webflow](https://webflow.com/updates/apple-well-known-files-in-webflow)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651e025318c50f92e19612a1_SlashUpdates_TransferSitePlan_2400x1400.jpeg)

Enhancement

Website management

## Transfer Site plans from one site to another

Learn more

→

[View Transfer Site plans from one site to another](https://webflow.com/updates/transfer-site-plans)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d68e_Site%20Activity%20Log%20for%20Content%20Editors_1500x1500_Social.jpg)

Enhancement

Website management

## Site Activity logs for Content Editors

Learn more

→

[View Site Activity logs for Content Editors](https://webflow.com/updates/site-activity-log-for-content-editors)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d67e_23008_16_Creator_Credits_SYBG_2400x1400_1.jpg)

Feature

Website management

## Showcase projects from a client’s Workspace

Learn more

→

[View Showcase projects from a client’s Workspace](https://webflow.com/updates/creator-credits)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d676_SYBG_RemoveYourselfFromAWorkspace_2400x1400%20(1).jpg)

Feature

Website management

## Remove yourself from a Workspace

Learn more

→

[View Remove yourself from a Workspace](https://webflow.com/updates/remove-yourself-from-workspace)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d672_SYBG_Designer_Performance_Updates_2023-05_2400x1260.jpg)

Enhancement

Website management

## Performance improvements in the Designer for large websites

Learn more

→

[View Performance improvements in the Designer for large websites](https://webflow.com/updates/designer-performance-improvements-at-scale)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d666_SAL-Filters_SYBG-Header_2400x1400.png)

Enhancement

Website management

## Find what you’re looking for faster in the Site Activity log with filters

Learn more

→

[View Find what you’re looking for faster in the Site Activity log with filters](https://webflow.com/updates/site-activity-log-filters)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d65e_sybg-updates-workspace-URL.jpg)

Update

Website management

## Choose your Workspace profile URL

Learn more

→

[View Choose your Workspace profile URL](https://webflow.com/updates/choose-your-workspace-profile-url)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d65a_SYBG_SetDefaultWorkspace_2023-01%20(1).png)

Feature

Website management

## Set a default Workspace to open your dashboard to the right place

Learn more

→

[View Set a default Workspace to open your dashboard to the right place](https://webflow.com/updates/set-a-default-workspace)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d654_sybg-Page-Branching-2400x1400.jpg)

Enhancement

Website management

## Bringing more power, control, and visibility to page branching

Learn more

→

[View Bringing more power, control, and visibility to page branching](https://webflow.com/updates/page-branching-enhancements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d61e_activity-log_sybg-updates.jpg)

Feature

Website management

## Fix site issues faster and track important design changes with the Site Activity log

Learn more

→

[View Fix site issues faster and track important design changes with the Site Activity log](https://webflow.com/updates/site-activity-log)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21ca2b_Screen%20Shot%202019-09-03%20at%2010.54.19%20AM.png)

Enhancement

Website management

## Search in the asset manager

Learn more

→

[View Search in the asset manager](https://webflow.com/updates/search-in-the-asset-manager)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c991_Screen%20Shot%202019-06-13%20at%2010.24.08%20AM.png)

Enhancement

Website management

## Share a read-only link of your project from the Designer

Learn more

→

[View Share a read-only link of your project from the Designer](https://webflow.com/updates/share-a-read-only-link-of-your-project-from-the-designer)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c8db_Screen%20Shot%202019-04-09%20at%205.28.44%20PM.png)

Enhancement

Website management

## Include project settings when duplicating sites

Learn more

→

[View Include project settings when duplicating sites](https://webflow.com/updates/include-project-settings-when-duplicating-sites)

## What’s new?

But that's not all... see the latest Webflow feature releases, product improvements and bug fixes.

[View all updates](https://webflow.com/updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/675b30a1de4dc833394a1389_cta-prefooter.avif)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)[iframe](https://td.doubleclick.net/td/rul/990123219?random=1745139142056&cv=11&fst=1745139142056&fmt=3&bg=ffffff&guid=ON&async=1&gtm=45be54h0h2v889784019za200&gcd=13l3l3l3l1l1&dma=0&tag_exp=102803279~102813109~102887800~102926062~103027016~103051953~103055465~103077950~103106314~103106316&u_w=1280&u_h=720&url=https%3A%2F%2Fwebflow.com%2Fupdates%2Fusage-dashboard&_ng=1&hn=www.googleadservices.com&frm=0&tiba=Usage%20Dashboard%20%7C%20Webflow%20Updates&npa=0&pscdl=noapi&auid=873071450.1745139142&fledge=1&data=event%3Dgtag.config)[iframe](https://td.doubleclick.net/td/rul/11074340254?random=1745139142073&cv=11&fst=1745139142073&fmt=3&bg=ffffff&guid=ON&async=1&gtm=45be54h0h2v889784019za200&gcd=13l3l3l3l1l1&dma=0&tag_exp=102803279~102813109~102887800~102926062~103027016~103051953~103055465~103077950~103106314~103106316&u_w=1280&u_h=720&url=https%3A%2F%2Fwebflow.com%2Fupdates%2Fusage-dashboard&_ng=1&hn=www.googleadservices.com&frm=0&tiba=Usage%20Dashboard%20%7C%20Webflow%20Updates&npa=0&pscdl=noapi&auid=873071450.1745139142&fledge=1&data=event%3Dgtag.config)![](https://segment.prod.bidr.io/associate-segment?buzz_key=tatari&segment_key=tatari-1022&value=&uncacheplz=1861805335)

![](https://bat.bing.com/action/0?ti=187060700&Ver=2&mid=ef8d5a09-2ab2-4498-8b74-c81a3f8c8f9b&bo=1&sid=c6015bb01dc411f0ab2025b73e10784c&vid=c60168001dc411f0be6a89df61b7f23a&vids=1&msclkid=N&uach=pv%3D10.0&pi=918639831&lg=en-US&sw=1280&sh=720&sc=24&tl=Usage%20Dashboard%20%7C%20Webflow%20Updates&p=https%3A%2F%2Fwebflow.com%2Fupdates%2Fusage-dashboard&r=&lt=664&evt=pageLoad&sv=1&cdb=ARoR&rn=609736)

[iframe](https://js.driftt.com/core/chat?d=1&region=US&driftEnableLog=false&pageLoadStartTime=1745139139463)

[iframe](https://js.driftt.com/core?d=1&embedId=b7n85m9zerm8&eId=b7n85m9zerm8&region=US&forceShow=false&skipCampaigns=false&sessionId=94b7256c-4d45-4bf9-8021-286d3034da98&sessionStarted=1745139142.209&campaignRefreshToken=902144e8-7873-4b0d-a0dd-c9303fedd2aa&hideController=false&pageLoadStartTime=1745139139463&mode=CHAT&driftEnableLog=false&secureIframe=false&u=https%3A%2F%2Fwebflow.com%2Fupdates%2Fusage-dashboard)