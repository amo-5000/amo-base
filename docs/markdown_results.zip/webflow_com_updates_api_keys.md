[iframe](https://117237908.intellimizeio.com/storage.html)Improved API token management \| Webflow Updates

[Skip to main content](https://webflow.com/updates/api-keys#main)

[Webflow](https://webflow.com/?r=0)

[Contact sales](https://webflow.com/contact-sales)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb21_f2382f890d505a114941a91d402ace26_webflow-desktop.avif)![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/673e4c2bd8b4c4111a43bb30_cfe5d91f9dbc640ed4dd82626c6d780b_webflow-tablet.avif)

[iframe](https://webflow.com/dashboard/signup-modal)

Trusted by teams at

![Ideo](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be2060749006212_58fb196935aa93002e9dcb9e1960e346_ideo-logo.svg)![Monday.com](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb22234476ba4209c7a_2a2e4d49a16cbf827caf34d631f571f7_monday.com.svg)![BBDO](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/672390266be206074900621d_a0d57b70cbf637736a3a186e369e1495_bbdo-logo.svg)![The New York Times](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209ce7_f65cede8603886ff8a92058ce445494c_nytimes.svg)![Ted](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cef_87a35dab6d903c1bdf093c990363fd07_TED.svg)![Philips](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/66bd4eb32234476ba4209cf9_1f3891936e4298c9ed02312ca75a7e4b_philips.svg)

[update](http://www.webflow.com/updates)

Enhancement

Integrations

# Improved API token management

Users can now generate scoped API tokens, generate multiple tokens per site, and name those tokens for easy reference.

![](https://webflow.com/updates/api-keys)

[updates](http://www.webflow.com/updates)

→

Improved API token management

Enhancement

Integrations

# Improved API token management

Users can now generate scoped API tokens, generate multiple tokens per site, and name those tokens for easy reference.

In this update

[Documentation\\
\\
→](https://university.webflow.com/lesson/intro-to-webflow-apis?topics=cms-dynamic-content#how-to-create-an-api-token)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/api-keys&text=Improved%20API%20token%20management)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/api-keys)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/api-keys&title=Improved%20API%20token%20management&summary=Users%20can%20now%20generate%20scoped%20API%20tokens,%20generate%20multiple%20tokens%20per%20site,%20and%20name%20those%20tokens%20for%20easy%20reference.)

Since launching the v2 of Webflow’s data APIs a few months ago, we have been working to improve the workflows around generating and managing Webflow API tokens.

**Here’s what’s new:**

- We’ve introduced scoped APIs and site tokens–allowing you to generate API tokens that only have access to the site data you specify.
- You can now generate more than one API token per site–so you can manage and configure individual API tokens as needed.
- Finally, you can now name your API tokens, making it easier to create and track API access across different tools and uses.

**A note about API v1 tokens** We will be removing the ability to generate new v1 API keys starting **August 15th 2024**, and sunsetting access to v1 API endpoints on **January 1st, 2025**.

We encourage any users currently using v1 API keys to generate new v2 API tokens, and update any relevant API calls to use our new v2 suite of APIs before August 15th, 2024. This will ensure that you can generate new API tokens as needed for your integration following that date.

‍

You can learn more about [Webflow API tokens here](https://university.webflow.com/lesson/intro-to-webflow-apis?topics=cms-dynamic-content#what-can-i-do-with-webflows-apis-). Or you can learn more about how to migrate to our new APIs, please review our [migration guide](https://developers.webflow.com/docs/migrating-to-v2) and [additional documentation here](https://docs.developers.webflow.com/docs/webflow-v1-api-deprecation-notice#important-dates).

‍

Launched on

March 8, 2024

Category

Integrations

[Documentation\\
\\
→](https://university.webflow.com/lesson/intro-to-webflow-apis?topics=cms-dynamic-content#how-to-create-an-api-token)

Share

[X](https://twitter.com/share?url=https://webflow.com/updates/api-keys&text=Improved%20API%20token%20management)

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https://webflow.com/updates/api-keys)

[LinkedIn](https://www.linkedin.com/shareArticle?url=https://webflow.com/updates/api-keys&title=Improved%20API%20token%20management&summary=Users%20can%20now%20generate%20scoped%20API%20tokens,%20generate%20multiple%20tokens%20per%20site,%20and%20name%20those%20tokens%20for%20easy%20reference.)

## Related updates

[Slide left\\
\\
←](https://webflow.com/updates/api-keys#) [Slide right\\
\\
→](https://webflow.com/updates/api-keys#)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/67a198a939e92273dd79bbc1_f2w-thumbnail.png)

Enhancement

Integrations

## Major Figma to Webflow improvements

Learn more

→

[View Major Figma to Webflow improvements](https://webflow.com/updates/major-figma-to-webflow-improvements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6759c119103daa33e31ec6de_SlashUpdates_1280x720.png)

Feature

Integrations

## Optimize Enterprise data integrations

Learn more

→

[View Optimize Enterprise data integrations](https://webflow.com/updates/optimize-integrations)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66fee46a8cf735b87fb766e1_SlashUpdates_1280x720.png)

Enhancement

Integrations

## Simplified Figma to Webflow Sync

Learn more

→

[View Simplified Figma to Webflow Sync](https://webflow.com/updates/simplified-figma-to-webflow-sync)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/66bcf86d7665872e36302a8f_SlashUpdates%20Figma%20to%20Webflow%20(1).jpg)

Enhancement

Integrations

## Figma to Webflow improvements

Learn more

→

[View Figma to Webflow improvements](https://webflow.com/updates/figma-to-webflow-improvements)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/6633a46b7a30e2733c8c90a5_SlashUpdates_1280x720_F2W%20Unit%20support.jpg)

Enhancement

Integrations

## Support for Rem and Em units in Figma to Webflow sync

Learn more

→

[View Support for Rem and Em units in Figma to Webflow sync](https://webflow.com/updates/support-for-rem-and-em-units-in-figma-to-webflow-sync)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/65d769aef84d5872c5946125_FigmaToWebflow_2400x1260.jpg)

Enhancement

Integrations

## Figma to Webflow App

Learn more

→

[View Figma to Webflow App](https://webflow.com/updates/figma-to-webflow-app)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/651df8d513b882d4e3adffea_APIs.jpg)

Update

Integrations

## New APIs: Component, Variables and Localization

Learn more

→

[View New APIs: Component, Variables and Localization](https://webflow.com/updates/api-updates-q323)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d699_SYBG_ArchiveWorkspace_2400x1400.jpg)

Update

Integrations

## Updates to our Developer Platform

Learn more

→

[View Updates to our Developer Platform](https://webflow.com/updates/developer-platform-updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d684_23008_19_DevLinkOpenBeta_SYBG_2400x1400.jpg)

Beta

Integrations

## DevLink open beta

Learn more

→

[View DevLink open beta](https://webflow.com/updates/devlink-open-beta)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d67d_23008_17_Figma_Combo_Class_SYBG_2400x1400.jpg)

Enhancement

Integrations

## Combo class support for Figma plugin

Learn more

→

[View Combo class support for Figma plugin](https://webflow.com/updates/figma-combo-class-support)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d644_Developer-resources-%E2%80%94-Blog.png)

Update

Integrations

## Developer resources

Learn more

→

[View Developer resources](https://webflow.com/updates/developer-resources)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d608_Hubspot-integration_Email_JV-compressed.png)

Feature

Integrations

## Connect your forms directly to HubSpot

Learn more

→

[View Connect your forms directly to HubSpot](https://webflow.com/updates/hubspot-integration)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21d601_Marketo-integration%20graphic.png)

Feature

Integrations

## Connect your forms directly to Marketo

Learn more

→

[View Connect your forms directly to Marketo](https://webflow.com/updates/marketo-integration)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c7e1_optimize.jpg)

Feature

Integrations

## Google Optimize integration

Learn more

→

[View Google Optimize integration](https://webflow.com/updates/google-optimize-integration)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c76c_Screen%20Shot%202018-11-05%20at%208.05.39%20PM.png)

Feature

Integrations

## More controls for YouTube embeds

Learn more

→

[View More controls for YouTube embeds](https://webflow.com/updates/more-controls-for-youtube-embeds)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a675/64f9399ca7d13575ff21c465_Screen%20Shot%202018-09-05%20at%2011.06.02%20AM.png)

Feature

Integrations

## Facebook pixel integration

Learn more

→

[View Facebook pixel integration](https://webflow.com/updates/facebook-pixel-integration)

## What’s new?

But that's not all... see the latest Webflow feature releases, product improvements and bug fixes.

[View all updates](https://webflow.com/updates)

![](https://cdn.prod.website-files.com/64f9399ca7d13575ff21a634/675b30a1de4dc833394a1389_cta-prefooter.avif)

 [![](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg)![Made in Webflow](https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg)](https://webflow.com/?utm_campaign=brandjs)